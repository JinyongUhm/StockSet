﻿#If ETRADE_CONNECTION Then
Imports XA_DATASETLib
#End If
Imports System.Data.SqlClient
Imports System.Xml

Public Class Form1
#If NO_SHOW_TO_THE_FORM Then
    Public HitList As New List(Of ListViewItem)
#End If
    Public Delegate Sub DelegateSortDateTime()
    Public Delegate Sub DelegateResultAnalysis()
    Public Delegate Sub DelegateCopyResultAndDeleteContents()
#If ETRADE_CONNECTION Then
    Private WithEvents _T1305 As New XAQuery
    Private WithEvents _ChartIndex As New XAQuery
    Private WithEvents _T8412 As New XAQuery           '190131: 왜 이벤트가 안 걸리는지 모르겠다. 다른 TR을 돌렸을 때는 어떤가 확인해보자.
    Public HistoryThread As New Threading.Thread(AddressOf HistoryProcess)
#End If
    Private ResponseReceived As Boolean
    Private RxProcessCompleted As Boolean
    Private RequestResult As Integer
    Public FailedSymbolNumber As Integer
    Public NoResponseNumber As Integer
    Public ProgressText1, ProgressText2, ProgressText3 As String
    Public LastExceptionErrorMesssage As String
    Public LoggedButAccountNotRequested As Boolean = False
    'Public StockMst2Obj As New StockMst2
    'Public StockBidObj As StockBid
#If ETRADE_CONNECTION Then
    Public WithEvents xa_session As XA_SESSIONLib.XASession
#End If
    Public Shared SVR_IP_VIRTUAL As String = "demo.etrade.co.kr"
    Public Shared SVR_PORT_VIRTUAL As String = "20001"
    Public Shared USER_ID_VIRTUAL As String = "jeanion"
    Public Shared USER_PASSWORD_VIRTUAL As String = "sejin00"
    Public Shared USER_CERT_VIRTUAL As String = "mio7ne3ry"
    Public Shared SVR_IP_REAL As String = "hts.ebestsec.co.kr"
    Public Shared SVR_PORT_REAL As String = "20001"
    Public Shared USER_ID_REAL As String = "jeanion"
    Public Shared USER_PASSWORD_REAL As String = "qlfkdjet"
    Public Shared USER_CERT_REAL As String = "rhdtkaxkr3937*"
    Private Const _STOCK_HI_PRICE As Integer = 100000000
    Private Const _LO_VOLUME As Long = 100000
    Private _Counting As Integer = 0
#If MOVING_AVERAGE_DIFFERENCE Then
    Public DBSupporter As c042_ChartDBSupport
#Else
    Public DBSupporter As c041_DefaultDBSupport
#End If
    'Public RealTimeMode As Boolean
    Public IsThreadExecuting As Boolean
    Public InvokingDone As Boolean = False
    Public AccelValueStored As Integer
    Private LogFileSaveTimeCount As Integer = 0
    Public Form_MAP_1 As Integer
    Public Form_MAP_2 As Double
    Public Form_MAP_3 As Double
    'Public Form_ENTER_POWER As Double
    'Public Form_EXIT_DIV As Double
    'Public Form_TIME_DIFF_FOR_RISING_DETECTION As Integer
    'Public Form_RISING_SLOPE_THRESHOLD As Double
    'Public Form_ENTERING_PROHIBIT_TIME As Integer
    Public BestCoeffs() As Double = {0.4268, 0.4268, 0.4268, 0.4268, 0.44, 0.44, 0.44, 0.44} ' 1.2, 1.2} ', 0.0846, 0.027, 16.2}
    Public SimulationResult As Double
    Public BestSimulationResult As Double = 4536938.67825408 '4534198.23737415 ' 4454854.973096    ' [Double].MinValue

    Private Sub Form1_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        AccelValueStored = trb_Accel.Value
#If MOVING_AVERAGE_DIFFERENCE Then
        DBSupporter = New c042_ChartDBSupport()       'DB supporter 생성
#Else
        DBSupporter = New c041_DefaultDBSupport()       'DB supporter 생성
#End If
        'If Not DBSupporter.DBStatusOK Then
        'MsgBox("DB 설정에 문제가 있어서 프로그램을 종료합니다.")
        '프로그램 종료
        'Me.Close()
        'Exit Sub
        'End If
        'tm_1mClock.Start()          'start 1minute timer
        'StockMst2Obj.SetInputValue(0, tb_StockCode.Text)        '종목 코드 세팅
        GlobalVarInit(Me)                   '전역변수 초기화

        'load past price information
        Dim file_list = My.Computer.FileSystem.GetFiles(".")
        Dim file_extension As String
        Dim file_name As String
        'Dim symbol_name As String
        Dim file_contents As List(Of String)
        For index As Integer = 0 To file_list.Count - 1
            file_extension = IO.Path.GetExtension(file_list(index))
            If file_extension = ".txt" Then
                file_name = IO.Path.GetFileName(file_list(index))
                If file_name.Substring(0, 9) = "history1_" Then
                    If file_name(9) = "A" Then
                        'no_response => 상장폐지 종목
                    Else
                        '종목 나왔다.
                        file_contents = IO.File.ReadAllLines(file_list(index)).ToList()
                        For line_index As Integer = 0 To file_contents.Count - 1

                        Next
                    End If
                End If
            End If

        Next
        'If MsgBox("실시간 모드로 할래요? (No는 시뮬레이션 모드)", MsgBoxStyle.YesNo) = MsgBoxResult.Yes Then
        '실시간 모드
        'RealTimeMode = True
        'SymbolCollection()                      '종목 알아내기
        'tm_15sClock_Tick(Nothing, Nothing)       'Get the very first data
        'tm_15sClock.Start()                     '15초 타이머 돌리기
        'TabControl1.SelectedTab = TabControl1.TabPages(1)
        'Else
        '시뮬레이션 모드
        'RealTimeMode = False
        TabControl1.SelectedTab = TabControl1.TabPages(2)
#If Not MOVING_AVERAGE_DIFFERENCE Then
        If DecisionByPattern Then
            '패턴용 트렌드 모니터용 칼럼 생성
            Dim new_column As ColumnHeader
            If GangdoDB Then
#If 0 Then
                new_column = New ColumnHeader()
                new_column.Tag = "f"
                new_column.Text = "BuyAmountCenter"
                new_column.Width = 60
                lv_DoneDecisions.Columns.Add(new_column)

                new_column = New ColumnHeader()
                new_column.Tag = "f"
                new_column.Text = "SelAmountCenter"
                new_column.Width = 60
                lv_DoneDecisions.Columns.Add(new_column)
#End If
                new_column = New ColumnHeader()
                new_column.Tag = "f"
                new_column.Text = "PatternGangdo"
                new_column.Width = 100
                lv_DoneDecisions.Columns.Add(new_column)
            End If

            For index As Integer = 1 To MAX_HAVING_LENGTH
                new_column = New ColumnHeader()
                new_column.Tag = "f"
                new_column.Text = "Trend" & index.ToString("##")
                new_column.Width = 60
                lv_DoneDecisions.Columns.Add(new_column)
            Next
        End If
#End If
        'End If
    End Sub

#If 0 Then
    Private Sub SymbolCollection()
        Dim cp_stock_code_obj As New CpStockCode
        Dim cp_code_mgr_obj As New CpCodeMgr
        Dim number_of_symbols As Integer = cp_stock_code_obj.GetCount
        Dim symbol_code As String
        Dim symbol_name As String
        Dim market_kind As Integer
        Dim control_kind As Integer
        Dim supervision_kind As Integer
        Dim status_kind As Integer
        Dim last_end_price As Long
        Dim list_view_item As ListViewItem
        Dim yester_price As Long
        Dim yester_amount As ULong
        Dim volume As Long
        Dim init_price As UInt32
        '        Dim amount As UInt64
        '        Dim gangdo As Double
        Dim symbol_obj As c03_Symbol = Nothing
        Dim bunch_obj As c02_Bunch = Nothing
        Dim selected_bunch_obj As c02_Bunch = Nothing

        'SymTree.StartSymbolListing()            '종목 모으기 시작
        ProgressText1 = "Symbol Collection step - "
        ProgressText2 = "0 / " & cp_stock_code_obj.GetCount
        ProgressText3 = ""
        For index As Integer = 0 To cp_stock_code_obj.GetCount - 1
            symbol_code = cp_stock_code_obj.GetData(0, index)
            symbol_name = cp_stock_code_obj.GetData(1, index)

            symbol_obj = New c03_Symbol(symbol_code, symbol_name)    '종목 개체 생성
            SymbolList.Add(symbol_obj)                                     '종목리스트에 추가
            market_kind = cp_code_mgr_obj.GetStockMarketKind(symbol_code)
            symbol_obj.MarketKind = market_kind         '마켓 종류 : 1: KOSPI, 2: KOSDAQ
            '130604: 대신증권 도움말에 종목별 증거금(100%,75%,50% 등) 알아내는 법을 알아보자. 근데 도움말 어떻게 읽어.
            symbol_obj.EvidanRate = cp_code_mgr_obj.GetStockMarginRate(symbol_code)     '증거금률 읽어오기
            control_kind = cp_code_mgr_obj.GetStockControlKind(symbol_code)
            supervision_kind = cp_code_mgr_obj.GetStockSupervisionKind(symbol_code)
            status_kind = cp_code_mgr_obj.GetStockStatusKind(symbol_code)
            last_end_price = cp_code_mgr_obj.GetStockYdClosePrice(symbol_code)

            If market_kind = 1 Or market_kind = 2 Then
                '소속부가 거래소 또는 코스닥이면
                If control_kind = 0 Or control_kind = 1 Then
                    '감리구분이 정상 또는 주의 이면
                    If supervision_kind = 0 Then
                        '관리구분이 일반종목이면
                        If status_kind = 0 Then
                            '주식상태가 거래정지나 거래중단이 아니면

                            If bunch_obj Is Nothing Then
                                '아직 번치가 생성되지 않았으면 하나 만든다
                                bunch_obj = New c02_Bunch(symbol_obj)
                            Else
                                '생성되어 있으면 종목을 덧붙인다.
                                bunch_obj.Add(symbol_obj)
                            End If

                            If bunch_obj.Count = _MAX_NUMBER_OF_REQUEST Then
                                '110개 다 모았으니 request 해야 된다.
                                bunch_obj.SymbolListFix()           '번치의 종목 리스트 마무리
                                bunch_obj.Mst2BlockRequest()        '리퀘스트...

                                For result_count As Integer = 0 To bunch_obj.Count - 1
                                    symbol_code = bunch_obj.GetSymbolCode(result_count)
                                    symbol_name = bunch_obj.GetSymbolName(result_count)
                                    yester_price = bunch_obj.GetYesterdayPrice(result_count)      '전일종가
                                    yester_amount = bunch_obj.GetYesterdayAmount(result_count)    '전일거래량
                                    volume = yester_price * yester_amount                                '전일거대래금

                                    If yester_price < _STOCK_HI_PRICE And volume >= _LO_VOLUME Then
                                        '너무 비싸지 않은 가격에 거래량이 충분히 있는 종목을 고른다.
                                        init_price = bunch_obj.GetNowPrice(result_count)
                                        'amount = bunch_obj.GetAmount(result_count)
                                        'gangdo = bunch_obj.GetGangdo(result_count)
                                        list_view_item = New ListViewItem(symbol_code)
                                        list_view_item.SubItems.Add(symbol_name)
                                        list_view_item.SubItems.Add(yester_price) '.ToString("n"))
                                        list_view_item.SubItems.Add(yester_amount)
                                        list_view_item.SubItems.Add(volume) '.ToString("n"))
                                        list_view_item.SubItems.Add(init_price)      '초기가
                                        list_view_item.SubItems.Add(0)         '현재가
                                        list_view_item.SubItems.Add(0)     '현재거래량
                                        'list_view_item.SubItems.Add(0)      '현재 체결강도
                                        list_view_item.SubItems.Add(0)          'data 갯수
                                        list_view_item.SubItems.Add(0)          '이동평균
                                        list_view_item.SubItems.Add(0)          '델타매수량
                                        list_view_item.SubItems.Add(0)          '델타매도량
                                        lv_Symbols.Items.Add(list_view_item)

                                        bunch_obj.Item(result_count).Initialize()           '해당 종목 주가 모니터링 시작
                                        bunch_obj.Item(result_count).LVItem = list_view_item    '리스트뷰아이템 설정
                                        '아래에서 첫 데이터를 넘겨준다.
                                        'bunch_obj.Item(result_count).SetNewData(now_price, amount, gangdo)
                                        'SymTree.AddSymbol(bunch_obj.Item(result_count))       'SymTree에 선택된 종목 넘긴다. 그러면 여기서 적당한 번치에 분배된다.
                                    Else
                                        '선택되지 않은 종목은 초기 가격정보를 지운다
                                        bunch_obj.Item(result_count).Initialize()
                                    End If

                                Next

                                MessageLogging(SymTree.Count.ToString & " 번치 끝")
                                '다음 번치를 위한 준비과정
                                bunch_obj.Terminate()
                                bunch_obj = Nothing
                            End If
                        End If
                    End If
                End If

            End If
            ProgressText2 = index & " / " & cp_stock_code_obj.GetCount
        Next

        If bunch_obj IsNot Nothing AndAlso bunch_obj.Count > 0 Then
            '110개 안 모였어도 request 해야 된다.
            bunch_obj.SymbolListFix()           '번치의 종목 리스트 마무리
            bunch_obj.Mst2BlockRequest()        '리퀘스트...

            For result_count As Integer = 0 To bunch_obj.Count - 1
                symbol_code = bunch_obj.GetSymbolCode(result_count)
                symbol_name = bunch_obj.GetSymbolName(result_count)
                yester_price = bunch_obj.GetYesterdayPrice(result_count)      '전일종가
                yester_amount = bunch_obj.GetYesterdayAmount(result_count)    '전일거래량
                volume = yester_price * yester_amount                                '전일거대래금

                If yester_price < _STOCK_HI_PRICE And volume >= _LO_VOLUME Then
                    '너무 비싸지 않은 가격에 거래량이 충분히 있는 종목을 고른다.
                    init_price = bunch_obj.GetNowPrice(result_count)
                    'amount = bunch_obj.GetAmount(result_count)
                    'gangdo = bunch_obj.GetGangdo(result_count)
                    list_view_item = New ListViewItem(symbol_code)
                    list_view_item.SubItems.Add(symbol_name)
                    list_view_item.SubItems.Add(yester_price) '.ToString("n"))
                    list_view_item.SubItems.Add(yester_amount)
                    list_view_item.SubItems.Add(volume) '.ToString("n"))
                    list_view_item.SubItems.Add(init_price)      '초기가
                    list_view_item.SubItems.Add(0)         '현재가
                    list_view_item.SubItems.Add(0)     '현재거래량
                    'list_view_item.SubItems.Add(0)      '현재 체결강도
                    list_view_item.SubItems.Add(0)          'data 갯수
                    list_view_item.SubItems.Add(0)          '이동평균
                    list_view_item.SubItems.Add(0)          '델타매수량
                    list_view_item.SubItems.Add(0)          '델타매도량
                    lv_Symbols.Items.Add(list_view_item)

                    bunch_obj.Item(result_count).Initialize()           '해당 종목 주가 모니터링 시작
                    bunch_obj.Item(result_count).LVItem = list_view_item    '리스트뷰아이템 설정
                    '아래에서 첫 데이터를 넘겨준다.
                    'bunch_obj.Item(result_count).SetNewData(now_price, amount, gangdo)
                    'SymTree.AddSymbol(bunch_obj.Item(result_count))       'SymTree에 선택된 종목 넘긴다. 그러면 여기서 적당한 번치에 분배된다.
                End If

            Next

            MessageLogging(SymTree.Count.ToString & " 마지막 번치 끝")
            '번치 클리어
            bunch_obj.Terminate()
            bunch_obj = Nothing
        Else
            '번치 클리어 할 필요 없다.
        End If

        'SymTree.FinishSymbolListing()           '종목 모으기 끝

        '종목리스트에 대해 DB 상태 정보 업데이트 =>나중에 저장할 때 한다.
        'DBSupporter.UpdateDBStatus()
        ProgressText1 = "Number of symbols : " & number_of_symbols_in_interest & " / " & number_of_symbols & ", Number of bunches: " & SymTree.Count
        'Text = lv_Symbols.Items.Count
    End Sub
#End If

    '131014 : 15초 timer를 5초 timer로 바꾸는 작업 개시.
    '5초마다 종목시세 업데이트
    'Private Sub tm_PriceClock_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles stm_PriceClock.Elapsed
    'If IsMarketTime Then
    '장중이면
    'SymTree.ClockSupply()           '시세 업데이트 클락 공급
    'End If
    'End Sub

    '시뮬레이션 시작
    Private Sub bt_StartSimul_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles bt_StartSimul.Click
        Dim simulate_thread As Threading.Thread = New Threading.Thread(AddressOf SimulateThread)
        simulate_thread.IsBackground = True
        simulate_thread.Start()     '시뮬레이션 스레드 돌리고  빠져나옴
        tm_FormUpdate.Start()       '관리 timer 시작
        'IsThreadExecuting = True
        bt_StartSimul.Enabled = False
    End Sub

    '넘겨받은 숫자에서 set된 bit 의 갯수를 돌려준다..
    Private Function SetBitCount(ByVal the_number As Integer) As Integer
        Dim mask As Integer
        Dim bit_count As Integer = 0

        For index As Integer = 0 To NUMBER_OF_COEFFS - 1
            mask = 2 ^ index
            If mask And the_number Then
                bit_count += 1
            End If
        Next

        Return bit_count
    End Function

    '조합 (Combination) 계산
    Private Function Combination(ByVal a As Integer, ByVal b As Integer)
        Dim result As Integer = 1

        For index As Integer = 1 To b
            result = result * (a + 1 - index)
        Next

        For index As Integer = b To 2 Step -1
            result = result / index
        Next

        Return result
    End Function

    '시뮬레이션 스레드용
    Private Sub SimulateThread()
        If SmartLearning Then
            'Coefficient 초기값 세팅
            Dim ALTER_FACTOR0 As Double = 0.03
            Dim ALTER_FACTOR1 As Double = 0.03
            Dim ALTER_FACTOR2 As Double = 0.03
            Dim ALTER_FACTOR3 As Double = 0.03
            Dim ALTER_FACTOR4 As Double = 0.03
            Dim ALTER_FACTOR5 As Double = 0.03
            Dim ALTER_FACTOR6 As Double = 0.03
            Dim ALTER_FACTOR7 As Double = 0.03
            Dim temp_coeffs() As Double
            Dim trial_indicator(2 ^ NUMBER_OF_COEFFS - 1) As Integer
            Dim number_of_coeffs_in_trial As Integer = 1
            Dim total_number_of_cards As Integer = Combination(NUMBER_OF_COEFFS, number_of_coeffs_in_trial)
            Dim used_number_of_cards As Integer = 0
            Dim random_gen As New Random
            Dim the_card As Integer
            Dim coeff0_alter, coeff1_alter, coeff2_alter, coeff3_alter, coeff4_alter, coeff5_alter, coeff6_alter, coeff7_alter As New List(Of Double)
            Dim coeffs_alter_list As New List(Of Double())
            Dim simulation_result_list As New List(Of Double)

            trial_indicator(0) = 1 '카드 0번은 아무 변화를 안 주겠다는 뜻이니까 시도할 필요도 없다.
            While 1
                '각 coefficient 업데이트
                'random generation 을 통해 변화를 줄 coefficient를 고른다.
                the_card = Math.Floor(random_gen.NextDouble() * (2 ^ NUMBER_OF_COEFFS))
                '뽑은 카드에 써진 coefficients 의 갯수가 number_of_coeffs_in_trial 과 일치하는지 본다. 일치하면 바로 밑으로 빠지고 아니면 다시 카드 뽑는다.
                While (SetBitCount(the_card) <> number_of_coeffs_in_trial) Or (trial_indicator(the_card) = 1)
                    the_card = Math.Floor(random_gen.NextDouble() * (2 ^ NUMBER_OF_COEFFS))
                End While
                trial_indicator(the_card) = 1
                used_number_of_cards += 1
                '뽑힌 카드로부터 시도할 coefficients list 를 도출해낼 것이다.
                '우선 각 coefficient 의 변이 list를 도출해낸다.
                coeff0_alter.Clear()
                If (the_card And 1) Then
                    'If CType(BestCoeffs(0), UInt32) = CType(BestCoeffs(0) * (1 - ALTER_FACTOR0), UInt32) Then
                    'If BestCoeffs(0) = 1 Then
                    'coeff0_alter.Add(BestCoeffs(0))
                    'Else
                    'coeff0_alter.Add(BestCoeffs(0) - 1)
                    'End If
                    'coeff0_alter.Add(BestCoeffs(0) + 1)
                    'Else
                    coeff0_alter.Add(BestCoeffs(0) * (1 - ALTER_FACTOR0))
                    coeff0_alter.Add(BestCoeffs(0) * (1 + ALTER_FACTOR0))
                    'End If
                Else
                    coeff0_alter.Add(BestCoeffs(0))
                End If
                coeff1_alter.Clear()
                If (the_card And 2) Then
                    'If CType(BestCoeffs(1), UInt32) = CType(BestCoeffs(1) * (1 - ALTER_FACTOR1), UInt32) Then
                    'coeff1_alter.Add(BestCoeffs(1) - 2)
                    'coeff1_alter.Add(BestCoeffs(1) + 2)
                    'Else
                    coeff1_alter.Add(BestCoeffs(1) * (1 - ALTER_FACTOR1))
                    coeff1_alter.Add(BestCoeffs(1) * (1 + ALTER_FACTOR1))
                    'End If
                Else
                    coeff1_alter.Add(BestCoeffs(1))
                End If
                coeff2_alter.Clear()
                If (the_card And 4) Then
                    'If CType(BestCoeffs(2), UInt32) = CType(BestCoeffs(2) * (1 - ALTER_FACTOR2), UInt32) Then
                    'coeff2_alter.Add(BestCoeffs(2) - 2)
                    'coeff2_alter.Add(BestCoeffs(2) + 2)
                    'Else
                    coeff2_alter.Add(BestCoeffs(2) * (1 - ALTER_FACTOR2))
                    coeff2_alter.Add(BestCoeffs(2) * (1 + ALTER_FACTOR2))
                    'End If
                Else
                    coeff2_alter.Add(BestCoeffs(2))
                End If
                coeff3_alter.Clear()
                If (the_card And 8) Then
                    'If CType(BestCoeffs(3), UInt32) = CType(BestCoeffs(3) * (1 - ALTER_FACTOR3), UInt32) Then
                    'coeff3_alter.Add(BestCoeffs(3) - 2)
                    'coeff3_alter.Add(BestCoeffs(3) + 2)
                    'Else
                    coeff3_alter.Add(BestCoeffs(3) * (1 - ALTER_FACTOR3))
                    coeff3_alter.Add(BestCoeffs(3) * (1 + ALTER_FACTOR3))
                    'End If
                Else
                    coeff3_alter.Add(BestCoeffs(3))
                End If
                coeff4_alter.Clear()
                If (the_card And 16) Then
                    'If CType(BestCoeffs(4), UInt32) = CType(BestCoeffs(4) * (1 - ALTER_FACTOR4), UInt32) Then
                    'coeff4_alter.Add(BestCoeffs(4) - 2)
                    'coeff4_alter.Add(BestCoeffs(4) + 2)
                    'Else
                    coeff4_alter.Add(BestCoeffs(4) * (1 - ALTER_FACTOR4))
                    coeff4_alter.Add(BestCoeffs(4) * (1 + ALTER_FACTOR4))
                    'End If
                Else
                    coeff4_alter.Add(BestCoeffs(4))
                End If
                coeff5_alter.Clear()
                If (the_card And 32) Then
                    'If CType(BestCoeffs(5), UInt32) = CType(BestCoeffs(5) * (1 - ALTER_FACTOR5), UInt32) Then
                    'coeff5_alter.Add(BestCoeffs(5) - 2)
                    'coeff5_alter.Add(BestCoeffs(5) + 2)
                    'Else
                    coeff5_alter.Add(BestCoeffs(5) * (1 - ALTER_FACTOR5))
                    coeff5_alter.Add(BestCoeffs(5) * (1 + ALTER_FACTOR5))
                    'End If
                Else
                    coeff5_alter.Add(BestCoeffs(5))
                End If
                coeff6_alter.Clear()
                If (the_card And 64) Then
                    coeff6_alter.Add(BestCoeffs(6) * (1 - ALTER_FACTOR6))
                    coeff6_alter.Add(BestCoeffs(6) * (1 + ALTER_FACTOR6))
                Else
                    coeff6_alter.Add(BestCoeffs(6))
                End If
                coeff7_alter.Clear()
                If (the_card And 128) Then
                    coeff7_alter.Add(BestCoeffs(7) * (1 - ALTER_FACTOR7))
                    coeff7_alter.Add(BestCoeffs(7) * (1 + ALTER_FACTOR7))
                Else
                    coeff7_alter.Add(BestCoeffs(7))
                End If
#If 0 Then
#End If
                coeffs_alter_list.Clear()
                simulation_result_list.Clear()
                For index0 As Integer = 0 To coeff0_alter.Count - 1
                    For index1 As Integer = 0 To coeff1_alter.Count - 1
                        For index2 As Integer = 0 To coeff2_alter.Count - 1
                            For index3 As Integer = 0 To coeff3_alter.Count - 1
                                For index4 As Integer = 0 To coeff4_alter.Count - 1
                                    For index5 As Integer = 0 To coeff5_alter.Count - 1
                                        For index6 As Integer = 0 To coeff6_alter.Count - 1
                                            For index7 As Integer = 0 To coeff7_alter.Count - 1
                                                temp_coeffs = {coeff0_alter(index0), coeff1_alter(index1), coeff2_alter(index2), coeff3_alter(index3), coeff4_alter(index4), coeff5_alter(index5), coeff6_alter(index6), coeff7_alter(index7)}
                                                coeffs_alter_list.Add(temp_coeffs)
                                            Next
                                        Next
                                    Next
                                Next
                            Next
                        Next
                    Next
                Next

                '만든 coefficients list를 가지고 돌려본다.
                TestIndex = 0
                CoefficientsAlterListLenth = coeffs_alter_list.Count
                NumberOfCoeffsInTrial = number_of_coeffs_in_trial
                Do
                    'MADIFFSCA_FADE_FACTOR_DEFAULT = coeffs_alter_list(TestIndex)(0)
                    MADIFFSCA_FADE_FACTOR_MA0035 = coeffs_alter_list(TestIndex)(0)
                    MADIFFSCA_FADE_FACTOR_MA0070 = coeffs_alter_list(TestIndex)(1)
                    MADIFFSCA_FADE_FACTOR_MA0140 = coeffs_alter_list(TestIndex)(2)
                    MADIFFSCA_FADE_FACTOR_MA0280 = coeffs_alter_list(TestIndex)(3)
                    MADIFFSCA_FADE_FACTOR_MA0560 = coeffs_alter_list(TestIndex)(4)
                    MADIFFSCA_FADE_FACTOR_MA1200 = coeffs_alter_list(TestIndex)(5)
                    MADIFFSCA_FADE_FACTOR_MA2400 = coeffs_alter_list(TestIndex)(6)
                    MADIFFSCA_FADE_FACTOR_MA4800 = coeffs_alter_list(TestIndex)(7)
                    'MADIFFSCA_DETECT_SCALE_MA0035 = coeffs_alter_list(TestIndex)(2)
                    'MADIFFSCA_DETECT_SCALE_MA0070 = coeffs_alter_list(TestIndex)(2)
                    'MADIFFSCA_DETECT_SCALE_MA0140 = coeffs_alter_list(TestIndex)(2)
                    'MADIFFSCA_DETECT_SCALE_MA0280 = coeffs_alter_list(TestIndex)(2)
                    'MADIFFSCA_DETECT_SCALE_MA0560 = coeffs_alter_list(TestIndex)(3)
                    'MADIFFSCA_DETECT_SCALE_MA1200 = coeffs_alter_list(TestIndex)(3)
                    'MADIFFSCA_DETECT_SCALE_MA2400 = coeffs_alter_list(TestIndex)(3)
                    'MADIFFSCA_DETECT_SCALE_MA4800 = coeffs_alter_list(TestIndex)(3)
                    'REDUCE_ASSIGN_RATE = coeffs_alter_list(TestIndex)(2)
                    'MADIFFSCA_A = coeffs_alter_list(TestIndex)(3)
                    'MADIFFSCA_B = coeffs_alter_list(TestIndex)(4)

                    'Form_DHT0 = coeffs_alter_list(TestIndex)(0)
                    'Form_DHT1 = coeffs_alter_list(TestIndex)(1)
                    'Form_DHT2 = coeffs_alter_list(TestIndex)(2)
                    'Form_DHT3 = coeffs_alter_list(TestIndex)(3)
                    'Form_DHT4 = coeffs_alter_list(TestIndex)(2)
                    'Form_DHT5 = coeffs_alter_list(TestIndex)(3)

                    '171022: 돌리고 나서 화면에 coeffs도 같이 표시해주게 하고, 결과는 simulation_result_list에 저장하자. 그리고 Do loop 빠져나오면
                    '171022: 결과중 maximum인 놈을 골라서 개선여부를 확인하자. 개선되면 best_coeffs 를 업데이트하고 같은 방향으로 몇 번 더해본다.
                    '171022: 개선 안 되면 밖의 while loop를 도는데 trial indicator 봐서 다 안 될 경우 number_of_coeffs_in_trial 을 증가시킨다.
                    '171022: trail indicator가 다 꽉차도록 개선이 없으면 종료한다.

                    InvokingDone = False
                    MainForm.BeginInvoke(New DelegateCopyResultAndDeleteContents(AddressOf RemoveContents))
                    '150812 : 위에 CopyResultAndRemoveContents 함수 만들자.
                    While InvokingDone = False
                        'wait until the invoking function finishes
                        Threading.Thread.Sleep(50)
                    End While


                    IsThreadExecuting = True           'thread 종료 flag reset
#If Not SIMULATION_PERIOD_IN_ARRAY Then
                    DBSupporter.Simulate(dtp_StartDate.Value.Date, dtp_EndDate.Value.Date)
#Else
                    'smart learning 에서는 test array에 의한 simulation하지 않는다.
                    'DBSupporter.Simulate()
#End If
                    IsThreadExecuting = False           'thread 종료 flag reset
                    '150811 : 아래 문 while 걸어서 invoking 종료 확인때까지 대기하는 거 넣자. 그리고 결과 clipboard로 카피하는 거 넣자
                    InvokingDone = False
                    MainForm.BeginInvoke(New DelegateSortDateTime(AddressOf SortDateTime))
                    While InvokingDone = False
                        'wait until the invoking function finishes
                        Threading.Thread.Sleep(50)
                    End While

                    '좀 쉬어서 소트 정보 확실히 반영되게 하자
                    Threading.Thread.Sleep(1000)

                    InvokingDone = False
                    MainForm.BeginInvoke(New DelegateResultAnalysis(AddressOf ResultAnalysis))
                    While InvokingDone = False
                        'wait until the invoking function finishes
                        Threading.Thread.Sleep(50)
                    End While

                    'copy to clipboard
                    InvokingDone = False
                    MainForm.BeginInvoke(New DelegateCopyResultAndDeleteContents(AddressOf CopyResult))
                    '150812 : 위에 CopyResultAndRemoveContents 함수 만들자.
                    While InvokingDone = False
                        'wait until the invoking function finishes
                        Threading.Thread.Sleep(50)
                    End While

                    simulation_result_list.Add(SimulationResult)
                    Threading.Thread.Sleep(1000)

                    TestIndex += 1
                Loop While TestIndex < coeffs_alter_list.Count

                'Best 결과를 찾는다.
                Dim max_result As Double = Double.MinValue
                Dim max_index As Integer = -1
                For result_index As Integer = 0 To simulation_result_list.Count - 1
                    If max_result < simulation_result_list(result_index) Then
                        max_result = simulation_result_list(result_index)
                        max_index = result_index
                    End If
                Next

                If max_result > BestSimulationResult Then
                    '개선되었다.
                    '같은 방향으로 몇 번 더 변이해보기 위해 변이량을 저장해둔다.
                    Dim delta(NUMBER_OF_COEFFS - 1) As Double
                    For coeff_index As Integer = 0 To NUMBER_OF_COEFFS - 1
                        delta(coeff_index) = coeffs_alter_list(max_index)(coeff_index) - BestCoeffs(coeff_index)
                    Next
                    'best coefficients와 best simulation result 업데이트
                    BestCoeffs = coeffs_alter_list(max_index)
                    BestSimulationResult = simulation_result_list(max_index)
                    TestIndex = 0
                    CoefficientsAlterListLenth = 0
                    NumberOfCoeffsInTrial = number_of_coeffs_in_trial
                    Do
                        'MADIFFSCA_FADE_FACTOR_DEFAULT = BestCoeffs(0) + delta(0)
                        MADIFFSCA_FADE_FACTOR_MA0035 = BestCoeffs(0) + delta(0)
                        MADIFFSCA_FADE_FACTOR_MA0070 = BestCoeffs(1) + delta(1)
                        MADIFFSCA_FADE_FACTOR_MA0140 = BestCoeffs(2) + delta(2)
                        MADIFFSCA_FADE_FACTOR_MA0280 = BestCoeffs(3) + delta(3)
                        MADIFFSCA_FADE_FACTOR_MA0560 = BestCoeffs(4) + delta(4)
                        MADIFFSCA_FADE_FACTOR_MA1200 = BestCoeffs(5) + delta(5)
                        MADIFFSCA_FADE_FACTOR_MA2400 = BestCoeffs(6) + delta(6)
                        MADIFFSCA_FADE_FACTOR_MA4800 = BestCoeffs(7) + delta(7)
                        'MADIFFSCA_DETECT_SCALE_MA0035 = BestCoeffs(2) + delta(2)
                        'MADIFFSCA_DETECT_SCALE_MA0070 = BestCoeffs(2) + delta(2)
                        'MADIFFSCA_DETECT_SCALE_MA0140 = BestCoeffs(2) + delta(2)
                        'MADIFFSCA_DETECT_SCALE_MA0280 = BestCoeffs(2) + delta(2)
                        'MADIFFSCA_DETECT_SCALE_MA0560 = BestCoeffs(3) + delta(3)
                        'MADIFFSCA_DETECT_SCALE_MA1200 = BestCoeffs(3) + delta(3)
                        'MADIFFSCA_DETECT_SCALE_MA2400 = BestCoeffs(3) + delta(3)
                        'MADIFFSCA_DETECT_SCALE_MA4800 = BestCoeffs(3) + delta(3)
                        'REDUCE_ASSIGN_RATE = BestCoeffs(2) + delta(2)
                        'MADIFFSCA_A = BestCoeffs(3) + delta(3)
                        'MADIFFSCA_B = BestCoeffs(4) + delta(4)
                        'Form_DHT0 = BestCoeffs(0) + delta(0)
                        'Form_DHT1 = BestCoeffs(1) + delta(1)
                        'Form_DHT2 = BestCoeffs(2) + delta(2)
                        'Form_DHT3 = BestCoeffs(3) + delta(3)
                        'Form_DHT4 = BestCoeffs(2) + delta(2)
                        'Form_DHT5 = BestCoeffs(3) + delta(3)

                        'remove contents
                        InvokingDone = False
                        MainForm.BeginInvoke(New DelegateCopyResultAndDeleteContents(AddressOf RemoveContents))
                        While InvokingDone = False
                            'wait until the invoking function finishes
                            Threading.Thread.Sleep(50)
                        End While

                        IsThreadExecuting = True           'thread 종료 flag reset
#If Not SIMULATION_PERIOD_IN_ARRAY Then
                        DBSupporter.Simulate(dtp_StartDate.Value.Date, dtp_EndDate.Value.Date)
#Else
                        'smart learning 에서는 test array에 의한 simulation 하지 않는다.
                        'DBSupporter.Simulate()
#End If
                        IsThreadExecuting = False           'thread 종료 flag reset

                        InvokingDone = False
                        MainForm.BeginInvoke(New DelegateSortDateTime(AddressOf SortDateTime))
                        While InvokingDone = False
                            'wait until the invoking function finishes
                            Threading.Thread.Sleep(50)
                        End While

                        '좀 쉬어서 소트 정보 확실히 반영되게 하자
                        Threading.Thread.Sleep(1000)

                        InvokingDone = False
                        MainForm.BeginInvoke(New DelegateResultAnalysis(AddressOf ResultAnalysis))
                        While InvokingDone = False
                            'wait until the invoking function finishes
                            Threading.Thread.Sleep(50)
                        End While

                        'copy to clipboard
                        InvokingDone = False
                        MainForm.BeginInvoke(New DelegateCopyResultAndDeleteContents(AddressOf CopyResult))
                        While InvokingDone = False
                            'wait until the invoking function finishes
                            Threading.Thread.Sleep(50)
                        End While

                        simulation_result_list.Add(SimulationResult)
                        Threading.Thread.Sleep(1000)

                        If SimulationResult > BestSimulationResult Then
                            '또 개선되었다. => Do loop 계속 돌리자
                            'BestCoeffs(0) = MADIFFSCA_FADE_FACTOR_DEFAULT
                            BestCoeffs(0) = MADIFFSCA_FADE_FACTOR_MA0035
                            BestCoeffs(1) = MADIFFSCA_FADE_FACTOR_MA0070
                            BestCoeffs(2) = MADIFFSCA_FADE_FACTOR_MA0140
                            BestCoeffs(3) = MADIFFSCA_FADE_FACTOR_MA0280
                            BestCoeffs(4) = MADIFFSCA_FADE_FACTOR_MA0560
                            BestCoeffs(5) = MADIFFSCA_FADE_FACTOR_MA1200
                            BestCoeffs(6) = MADIFFSCA_FADE_FACTOR_MA2400
                            BestCoeffs(7) = MADIFFSCA_FADE_FACTOR_MA4800
                            'BestCoeffs(2) = MADIFFSCA_DETECT_SCALE_MA0035
                            'BestCoeffs(2) = MADIFFSCA_DETECT_SCALE_MA0070
                            'BestCoeffs(2) = MADIFFSCA_DETECT_SCALE_MA0140
                            'BestCoeffs(2) = MADIFFSCA_DETECT_SCALE_MA0280
                            'BestCoeffs(3) = MADIFFSCA_DETECT_SCALE_MA0560
                            'BestCoeffs(3) = MADIFFSCA_DETECT_SCALE_MA1200
                            'BestCoeffs(3) = MADIFFSCA_DETECT_SCALE_MA2400
                            'BestCoeffs(3) = MADIFFSCA_DETECT_SCALE_MA4800
                            'BestCoeffs(2) = REDUCE_ASSIGN_RATE
                            'BestCoeffs(3) = MADIFFSCA_A
                            'BestCoeffs(4) = MADIFFSCA_B
                            'BestCoeffs(0) = Form_MAP_1
                            'BestCoeffs(1) = Form_MAP_2
                            'BestCoeffs(2) = Form_MAP_3

                            BestSimulationResult = SimulationResult
                        Else
                            '개선되지 않았다. => 그만 do loop를 빠져나오자.
                            Exit Do
                        End If
                    Loop
#If 1 Then      '각 bit 변위가 독립적일 때에는 trial flag를 reset할 필요가 없다.
                    '이제 이 개선된 상태에서 다시 1 bit 짜리 변이를 일으켜 돌려보자.
                    For card_index As Integer = 1 To 2 ^ NUMBER_OF_COEFFS - 1
                        'trial indicator reset 한다. index 0 은 reset 하지 않음에 유의하라.
                        trial_indicator(card_index) = 0
                    Next
                    number_of_coeffs_in_trial = 1
                    total_number_of_cards = NUMBER_OF_COEFFS
                    used_number_of_cards = 0
#End If
                Else
                    '개선 안 되었다.
                    If total_number_of_cards = used_number_of_cards Then
                        '현재 하고 있는 변이 coefficients 갯수에서는 할 걸 다 해봤다. => 변이 coefficients 갯수를 증가시킨다.
                        If number_of_coeffs_in_trial = NUMBER_OF_COEFFS Then
                            '더 이상 해볼 게 없다. => Give up
                            Exit While
                        Else
                            number_of_coeffs_in_trial += 1
                            total_number_of_cards = Combination(NUMBER_OF_COEFFS, number_of_coeffs_in_trial)
                            used_number_of_cards = 0
                        End If
                    Else
                        '현재 하고 있는 변이 coefficients 갯수에서 아직 할 게 남아 있다. => 다음 카드 뽑으러 간다.
                    End If
                End If
            End While
        Else
            '150806 : 여기서 아래 DBSupporter.Simulate을 For 문으로 돌리자
            For m00_Global.TestIndex = 0 To TestArray.Count - 1
                SimulationDateCollector.Clear()     'TestArray가 날짜별로 되어 있는 경우는 clear 안 해주면 날짜가 계속 누적되어 이상해진다.
                InvokingDone = False
                MainForm.BeginInvoke(New DelegateResultAnalysis(AddressOf RemoveContents))
                While InvokingDone = False
                    'wait until the invoking function finishes
                    Threading.Thread.Sleep(50)
                End While

                IsThreadExecuting = True           'thread 종료 flag reset
#If Not SIMULATION_PERIOD_IN_ARRAY Then
                DBSupporter.Simulate(dtp_StartDate.Value.Date, dtp_EndDate.Value.Date)
#Else
                DBSupporter.Simulate(Convert.ToDateTime(TestArray(TestIndex)), Convert.ToDateTime(TestArray2(TestIndex)))
#End If
                IsThreadExecuting = False           'thread 종료 flag reset
#If 1 Then
                'GlobalData 계산
                If TwoStepSearching Then
                    'Enter time 순으로 다시 sort
                    InvokingDone = False
                    MainForm.BeginInvoke(New DelegateSortDateTime(AddressOf SortDateTime))
                    While InvokingDone = False
                        'wait until the invoking function finishes
                        Threading.Thread.Sleep(50)
                    End While

                    '좀 쉬어서 소트 정보 확실히 반영되게 하자
                    Threading.Thread.Sleep(1000)

                    '결과 분석
                    InvokingDone = False
                    MainForm.BeginInvoke(New DelegateResultAnalysis(AddressOf ResultAnalysis))
                    While InvokingDone = False
                        'wait until the invoking function finishes
                        Threading.Thread.Sleep(50)
                    End While

                    'Sort하고 global data 계산
                    InvokingDone = False
                    MainForm.BeginInvoke(New DelegateSortDateTime(AddressOf SortToMakeGlobalData))
                    While InvokingDone = False
                        'wait until the invoking function finishes
                        Threading.Thread.Sleep(50)
                    End While

                    'copy to clipboard
                    InvokingDone = False
                    MainForm.BeginInvoke(New DelegateCopyResultAndDeleteContents(AddressOf CopyResult))
                    While InvokingDone = False
                        'wait until the invoking function finishes
                        Threading.Thread.Sleep(50)
                    End While

                    'remove contents
                    InvokingDone = False
                    MainForm.BeginInvoke(New DelegateCopyResultAndDeleteContents(AddressOf RemoveContents))
                    While InvokingDone = False
                        'wait until the invoking function finishes
                        Threading.Thread.Sleep(50)
                    End While

                    Threading.Thread.Sleep(1000)

                    '2021.04.13: 여기서 flag 하나 세팅하고 DBSupporter.Simulate()를 한 번 더 돌린다. Decision 객체에서는 flag에 따라 다른 알고리즘을 적용하여, 예를 들면 현재 걸린애들이 없는 상태에서 최초 걸리면 바로 진입 안하고 조금 기다린 후 가격 떨어진 경우 진입하던가 하고, 현재 걸린 애들이 많은 상태에서 걸리면 바로 진입한다던가 하는 것이다.
                    SecondStep = True

                    IsThreadExecuting = True           'thread 종료 flag reset
#If Not SIMULATION_PERIOD_IN_ARRAY Then
                    DBSupporter.Simulate(dtp_StartDate.Value.Date, dtp_EndDate.Value.Date)
#Else
                    DBSupporter.Simulate(Convert.ToDateTime(TestArray(TestIndex)), Convert.ToDateTime(TestArray2(TestIndex)))
#End If
                    IsThreadExecuting = False           'thread 종료 flag reset

                Else
                    '150811 : 아래 문 while 걸어서 invoking 종료 확인때까지 대기하는 거 넣자. 그리고 결과 clipboard로 카피하는 거 넣자
                    InvokingDone = False
                    MainForm.BeginInvoke(New DelegateSortDateTime(AddressOf SortDateTime))
                    While InvokingDone = False
                        'wait until the invoking function finishes
                        Threading.Thread.Sleep(50)
                    End While

                    '좀 쉬어서 소트 정보 확실히 반영되게 하자
                    Threading.Thread.Sleep(1000)

                    InvokingDone = False
                    MainForm.BeginInvoke(New DelegateResultAnalysis(AddressOf ResultAnalysis))
                    While InvokingDone = False
                        'wait until the invoking function finishes
                        Threading.Thread.Sleep(50)
                    End While

                    'copy to clipboard
                    InvokingDone = False
                    MainForm.BeginInvoke(New DelegateCopyResultAndDeleteContents(AddressOf CopyResult))
                    '150812 : 위에 CopyResultAndRemoveContents 함수 만들자.
                    While InvokingDone = False
                        'wait until the invoking function finishes
                        Threading.Thread.Sleep(50)
                    End While
                    Threading.Thread.Sleep(1000)
                End If
#End If

            Next
        End If
    End Sub

    Public Sub CopyResult()
        'Copy result
        SaveAnalysis_Click(Nothing, Nothing)
        InvokingDone = True
    End Sub

    Public Sub RemoveContents()
        'Remove contents in the ListView
        If SmartLearning Then
            '171023: 밑에 꺼 때문에 한참 헤맸다. 다 지워버리도록 수정했다.
#If NO_SHOW_TO_THE_FORM Then
            HitList.Clear()
            For index As Integer = 0 To SymbolList.Count - 1
                SymbolList(index).Initialize()
            Next
#Else
            lv_DoneDecisions.Items.Clear()
#End If
        Else
#If NO_SHOW_TO_THE_FORM Then
            If TestIndex <> TestArray.Count - 1 Then
                For index As Integer = 0 To HitList.Count - 1
                    HitList(index).Tag = Nothing         '이렇게 하면 아웃오브메모리 좀 덜 날까
                Next
                HitList.Clear()
            End If
#Else
            'If TestIndex <> TestArray.Count - 1 Then
            For index As Integer = 0 To lv_DoneDecisions.Items.Count - 1
                lv_DoneDecisions.Items(index).Tag = Nothing         '이렇게 하면 아웃오브메모리 좀 덜 날까
            Next
            lv_DoneDecisions.Items.Clear()
            'End If
#End If
        End If
        InvokingDone = True
#If CHECK_PRE_PATTERN_STRATEGY Then
        CountPostPatternFail = 0
#End If
    End Sub

    'Form update timer
    Private Sub tm_FormUpdate_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tm_FormUpdate.Tick
        If IsThreadExecuting Then
            If bt_StartSimul.Enabled = False Then
                '시뮬레이션
#If MOVING_AVERAGE_DIFFERENCE Then
                'Chart DB 쓰는 거
                If SmartLearning Then
                    ProgressText1 = DBSupporter.DBProgressValue & " / " & DBSupporter.DBProgressMax & " - BestSimulationResult: " & BestSimulationResult.ToString("##,#.###") & ". " & TestIndex.ToString() & " / " & CoefficientsAlterListLenth.ToString() & ". Bits: " & NumberOfCoeffsInTrial.ToString()
                Else
                    ProgressText1 = DBSupporter.DBProgressValue & " / " & DBSupporter.DBProgressMax & " - TestIndex :" & TestIndex.ToString & " / " & TestArray.Length.ToString
                End If
#Else
                'Chart DB 안 쓰는 거
                If SmartLearning Then
                    Me.Text = DBSupporter.ProgressValue & " / " & DBSupporter.ProgressMax & " in DB " & DBSupporter.DBProgressValue & " / " & DBSupporter.DBProgressMax & " - BestSimulationResult: " & BestSimulationResult.ToString("##,#.###") & ". " & TestIndex.ToString() & " / " & CoefficientsAlterListLenth.ToString() & ". Bits: " & NumberOfCoeffsInTrial.ToString()
                Else
                    Me.Text = DBSupporter.ProgressValue & " / " & DBSupporter.ProgressMax & " in DB " & DBSupporter.DBProgressValue & " / " & DBSupporter.DBProgressMax & " - TestIndex :" & TestIndex.ToString & " / " & TestArray.Length.ToString
                End If
                If DBSupporter.ProgressMax <> 0 Then
                    pb_Progress.Value = DBSupporter.ProgressValue * 100 / DBSupporter.ProgressMax
                End If
#End If

            ElseIf bt_ChartDataUpdate.Enabled = False Then
                '차트 데이터 업데이트 중
                Me.Text = ProgressText1 & " " & ProgressText2 & " " & ProgressText3
                'If TotalNumber <> 0 Then
                'Me.Text = "Getting ChartData : " & CurrentNumber & " / " & TotalNumber
                'End If
            End If
#If MOVING_AVERAGE_DIFFERENCE Then
            Me.Text = ProgressText1 & " " & ProgressText2 & " " & ProgressText3
#End If
        Else
            'thread 종료 되었음
            '150816 : 여러번 실행되게 하면서 아래 세 라인 주석처리됨
            'IsThreadExecuting = False
            'bt_StartSimul.Enabled = True
            'tm_FormUpdate.Stop()
        End If
        'log file save 하기
        'LogFileSaveTimeCount = (LogFileSaveTimeCount + 1) Mod 10
        'If LogFileSaveTimeCount = 0 Then
        Dim messages_in_one_line As String = ""
        '2초에 한 번씩 로그를 파일로 저장
        SafeEnterTrace(StoredMessagesKeyForDisplay, 70)      'Enter critical zone, Thread간 공유문제 발생예방------------------------------------┐
        For index As Integer = 0 To StoredMessagesForFileSave.Count - 1
            messages_in_one_line = messages_in_one_line & StoredMessagesForFileSave(index)
        Next
        tb_Display.AppendText(messages_in_one_line)
        Try
            'My.Computer.FileSystem.WriteAllText("log" & Now.Year.ToString("D4") & Now.Month.ToString("D2") & Now.Day.ToString("D2") & ".txt", messages_in_one_line, True)
            StoredMessagesForFileSave.Clear()
        Catch ex As Exception
            MsgBox("Log file save 중 에러!! - " & ex.Message)
        End Try
        SafeLeaveTrace(StoredMessagesKeyForDisplay, 71)      'Leave critical zone, Thread간 공유문제 발생예방------------------------------------┘
        'End If
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        'Save stocks for tomorrow

#If 0 Then
        If MsgBox("위험! DB 제거 혹은 추가!", MsgBoxStyle.OkCancel) Then
            Dim remove_chart_db_contain_nothing_thread As Threading.Thread = New Threading.Thread(AddressOf RemoveAllChartDB)

            tm_FormUpdate.Start()       '관리 timer 시작
            'stm_PriceClock.Stop()         '가격 타이머 돌아가고 있으면 멈춘다.

            remove_chart_db_contain_nothing_thread.IsBackground = True
            remove_chart_db_contain_nothing_thread.Start()     '시뮬레이션 스레드 돌리고  빠져나옴
        End If
#End If

#If CHECK_PRE_PATTERN_STRATEGY Then
        MainForm.Text = CountPostPatternFail
#End If
#If 0 Then
        Dim cat As ADOX.Catalog = New ADOX.Catalog()

        cat.Create("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=D:\\Finance\\Database\\testing.accdb;")
        Dim _DB_connection As OleDb.OleDbConnection = New OleDb.OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=D:\\Finance\\Database\\testing.accdb;")

        _DB_connection.Open()

        '테이블 이름 리스트를 만든다.
        Dim data_table As DataTable = _DB_connection.GetSchema("tables")
        Dim table_name_list = New List(Of String)
        For table_index As Integer = 0 To data_table.Rows.Count - 1
            table_name_list.Add(data_table.Rows(table_index).Item(2).ToString)           '2번째 컬럼이 TABLE_NAME이다.
        Next
#End If
#If 0 Then
        Dim my_conn As SqlConnection = New SqlConnection("Server=" & PCName & "; database=master;")
        my_conn.Open()
        Dim Str As String = "CREATE DATABASE MyDatabase ON PRIMARY " & _
              "(NAME = MyDatabase_Data, " & _
              " FILENAME = 'D:\MyFolder\MyDatabaseData.mdf', " & _
              " SIZE = 2MB, " & _
              " MAXSIZE = 10MB, " & _
              " FILEGROWTH = 10%) " & _
              " LOG ON " & _
              "(NAME = MyDatabase_Log, " & _
              " FILENAME = 'D:\MyFolder\MyDatabaseLog.ldf', " & _
              " SIZE = 1MB, " & _
              " MAXSIZE = 5MB, " & _
              " FILEGROWTH = 10%) "

        Dim myCommand As SqlCommand = New SqlCommand(Str, my_conn)
#End If
#If 0 Then
        Dim _DB_connection As OleDb.OleDbConnection = New OleDb.OleDbConnection("Provider=SQLOLEDB;Data Source=" & PCName & "\SQLEXPRESS;Integrated Security=SSPI")
        _DB_connection.Open()

        Dim Str As String = "CREATE DATABASE MyDatabase ON PRIMARY " & _
              "(NAME = MyDatabase_Data, " & _
              " FILENAME = 'D:\MyFolder\MyDatabaseData.mdf') " & _
              " LOG ON " & _
              "(NAME = MyDatabase_Log, " & _
              " FILENAME = 'D:\MyFolder\MyDatabaseLog.ldf', " & _
              " FILEGROWTH = 10%) "
        Dim cmd As New OleDb.OleDbCommand(Str, _DB_connection)
        cmd.ExecuteNonQuery()
        _DB_connection.Close()
#End If
#If ETRADE_CONNECTION Then
        HistoryThread.Start()
#End If

    End Sub

#If ETRADE_CONNECTION Then
    Private Sub HistoryProcess()
        'Get the symbol name list
#If 0 Then
         "PriceFineDB_201401", _
         "PriceFineDB_201402", _
         "PriceFineDB_201403", _
         "PriceFineDB_201404", _
         "PriceFineDB_201405", _
         "PriceFineDB_201406", _
         "PriceFineDB_201407", _
         "PriceFineDB_201408", _
         "PriceFineDB_201409", _
         "PriceFineDB_201410", _
         "PriceFineDB_201411", _
         "PriceFineDB_201412", _
         "PriceFineDB_201501", _
         "PriceFineDB_201502", _
         "PriceFineDB_201503", _
         "PriceFineDB_201504", _
         "PriceFineDB_201505", _
         "PriceFineDB_201506", _
         "PriceFineDB_201507", _
         "PriceFineDB_201508", _
         "PriceFineDB_201509", _
         "PriceFineDB_201510", _
         "PriceFineDB_201511", _
         "PriceFineDB_201512", 
#End If
        Dim _DBList() As String = { _
         "PriceFineDB_201607", _
         "PriceFineDB_201608", _
         "PriceFineDB_201609" _
        }

        Dim db_connection As OleDb.OleDbConnection
        Dim data_table As DataTable
        Dim table_name As String
        Dim table_name_list As New List(Of String)
        For db_index As Integer = 0 To _DBList.Count - 1
            db_connection = New OleDb.OleDbConnection("Provider=SQLOLEDB;Data Source=" & PCName & "\SQLEXPRESS; Initial Catalog=" & _DBList(db_index) & "; Integrated Security=SSPI;")
            db_connection.Open()
            data_table = db_connection.GetSchema("tables")
            For table_index As Integer = 0 To data_table.Rows.Count - 1
                table_name = data_table.Rows(table_index).Item(2).ToString
                '테이블 이름이 종목코드와 같은 형식인지 검사(첫자가 A이고 길이가 7)
                If table_name(0) = "A" And table_name.Length = 7 Then
                    If Not table_name_list.Contains(table_name) Then
                        table_name_list.Add(table_name)
                    End If
                End If
            Next
            db_connection.Close()
        Next
        Dim sub_str As String
        For table_index As Integer = 0 To table_name_list.Count - 1
            _T1305.ResFileName = "Res\t1305.res"
            sub_str = table_name_list(table_index).Substring(1, table_name_list(table_index).Length - 1)
            _T1305.SetFieldData("t1305InBlock", "shcode", 0, sub_str) ' table_name_list(table_index).Substring(1, table_name_list(table_index).Length - 1)) ' table_name_list(table_index).Substring(2,table_name_list(table_index).Length-1)
            _T1305.SetFieldData("t1305InBlock", "dwmcode", 0, 1L)
            '_T1305.SetFieldData("t1305InBlock", "date", 0, "")
            '_T1305.SetFieldData("t1305InBlock", "idx", 0, 0L)
            _T1305.SetFieldData("t1305InBlock", "cnt", 0, 500L)
            ResponseReceived = False
            RequestResult = _T1305.Request(False)
            If RequestResult > 0 Then
                Dim a = 0
                Do
                    a = a + 1
                    Threading.Thread.Sleep(10)
                    If a = 500 Then
                        My.Computer.FileSystem.WriteAllText("history1_" & table_name_list(table_index) & "_noresponse.txt", "", False)
                        NoResponseNumber = NoResponseNumber + 1
                        _T1305 = New XAQuery
                        Exit Do
                    End If
                Loop Until ResponseReceived
            Else
                FailedSymbolNumber = FailedSymbolNumber + 1
                My.Computer.FileSystem.WriteAllText("history1_" & table_name_list(table_index) & "_failed" & RequestResult.ToString & ".txt", "", False)
            End If
            Threading.Thread.Sleep(5000)
            My.Computer.FileSystem.WriteAllText("status.txt", "Current index : " & table_index.ToString & vbCrLf & "Failed : " & FailedSymbolNumber.ToString & vbCrLf & "No response : " & NoResponseNumber.ToString, False)
        Next
    End Sub

    Private Sub LoginProcess()
        Dim svr_ip As String
        Dim svr_port As String
        Dim user_id As String
        Dim user_password As String
        Dim user_cert As String
        Dim virtual_account_login As Integer

        '실제 계좌 로그인
        svr_ip = SVR_IP_REAL
        svr_port = SVR_PORT_REAL
        user_id = USER_ID_REAL
        user_password = USER_PASSWORD_REAL
        user_cert = USER_CERT_REAL
        virtual_account_login = 0

        ' XASession 객체를 생성한다.
        xa_session = New XA_SESSIONLib.XASession

        ' 이미 접속이 되어 있으면 접속을 끊는다.
        xa_session.DisconnectServer()

        ' 서버에 연결한다.
        If xa_session.ConnectServer(svr_ip, svr_port) = False Then
            MsgBox(xa_session.GetErrorMessage(xa_session.GetLastError()))
            Exit Sub
        End If
        ' 로그인 한다.
        If xa_session.Login(user_id, user_password, user_cert, virtual_account_login, False) = False Then
            MsgBox("로그인 전송 실패")
        Else
            '로그인 성공
            'LoggedIn = True
        End If

    End Sub
#End If

    '디시전 아이템 선택시
    Private Sub lv_DoneDecisions_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles lv_DoneDecisions.SelectedIndexChanged
        'GDP에 표시하자
        gdp_Display.ClearAllGraphs()        '이전 그래프 모두 삭제

        If lv_DoneDecisions.SelectedItems.Count > 0 Then
            Dim the_decision_object As c050_DecisionMaker = lv_DoneDecisions.SelectedItems(0).Tag
            For index As Integer = 0 To the_decision_object.GraphicCompositeDataList.Count - 1
                gdp_Display.AddCompositeData(the_decision_object.GraphicCompositeDataList(index))
                If the_decision_object.GraphicCompositeDataList(index).Name = "DeltaGangdo" Then
                    gdp_Display.Graphs.Item(index).YScaleManager.LogScaleOption = True
                End If
            Next
        End If
        'Pause Time하자
        gdp_Display.PauseTime()
    End Sub

    '결과 분석 버튼 누름
    Private Sub bt_ProfitAnalyze_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles bt_ProfitAnalyze.Click
        ResultAnalysis()
    End Sub

    Public Sub ResultAnalysis()
#If NO_SHOW_TO_THE_FORM Then
        Dim hit_list = HitList
#Else
        Dim hit_list = lv_DoneDecisions.Items
#End If
        '150808 : 여기서 Form 소속 데이터 업데이트하는 거는 전부 이미지 변수를 만들어서 이미지변수와 해당 폼콘트롤을 주기함수에서 매주기마다 동기화하는 걸로 바꾸자.
        '150810 : 아니다 필요 때마다 invoke 시켜서 하는 게 낫겠다. ListView 등은 이미지 변수 같은 거 생각도 못한다.
        '시작 날짜
        lb_BeginDate.Text = lb_BeginDate.Tag.ToString & dtp_StartDate.Value.ToString("yyyy.MM.dd")
        '종료 날짜
        lb_EndDate.Text = lb_EndDate.Tag.ToString & dtp_EndDate.Value.ToString("yyyy.MM.dd")
        '분석 날짜
        lb_AnalyzeDate.Text = lb_AnalyzeDate.Tag.ToString & Now.Date.ToString("yyyy.MM.dd")

        '날짜 수 count
        'Dim previous_date As String = ""
        Dim date_count As Integer = SimulationDateCollector.Count
        'Dim total_volume As Decimal = 0
        'For index As Integer = 0 To hit_list.Count - 1
        'If hit_list(index).Text <> previous_date Then
        'date_count = date_count + 1
        'previous_date = hit_list(index).Text
        'End If

        'total_volume += CType(hit_list(index).Tag, c050_DecisionMaker).FallVolume
        'Next
        '유효 일수
        lb_DateCount.Text = lb_DateCount.Tag.ToString & date_count.ToString
        '적용 전략명
        If hit_list.Count > 0 Then
            Dim decision_maker_sample As c050_DecisionMaker = hit_list(0).Tag
            lb_StrategyName.Text = lb_StrategyName.Tag.ToString & decision_maker_sample.GetType.ToString.Split(".")(1)
        Else
            lb_StrategyName.Text = "걸린애들없다"
        End If

        '겹침제외 일평균 검색건수 및 겹침 제외 일평균 최대 벌이. 뿐만 아니라 검색된 건수, profit도 여기서 count하기로 한다.
        Dim hit_count As Integer = 0
        Dim no_overlap_hit_count As Integer = 0
#If MOVING_AVERAGE_DIFFERENCE Then
        Dim enter_datetime_of_the_current_hit As DateTime
        Dim enter_datetime_of_the_previous_hit As DateTime = [DateTime].MinValue
        Dim minutes_passed_of_the_current_hit As Integer
        Dim minutes_passed_of_the_previous_hit As Integer = [Integer].MinValue
        Dim end_datetime_of_running_hit_no_overlap As DateTime = [DateTime].MinValue
        Dim end_datetime_of_running_hit_no_overlap_old As DateTime = [DateTime].MinValue
#Else
        Dim date_of_the_current_hit As String
        Dim date_of_the_previous_hit As String = ""
        Dim enter_time_of_the_current_hit As String
        Dim enter_time_of_the_previous_hit As String = ""
        Dim end_time_of_running_hit_no_overlap As String = ""
        Dim end_time_of_running_hit_no_overlap_old As String = ""
#End If
        Dim symbol_name_of_the_current_hit As String
        Dim symbol_name_of_the_previous_hit As String = ""
        Dim duplicated As Boolean = False
        Dim no_overlap_max_earned As Double = 0
        Dim no_overlap_total_profit_plus1 As Double = 1
        Dim the_decision_obj As c050_DecisionMaker
        Dim profit_product As Double = 1
        Dim min_profit As Double = [Double].MaxValue
        Dim max_profit As Double = [Double].MinValue
        Dim total_volume As Decimal = 0
        Dim max_earned As Double = 0
        Dim ave_invest As Double
        Dim running_hit_list_indexing As New List(Of Integer)

        For index As Integer = 0 To hit_list.Count - 1
#If MOVING_AVERAGE_DIFFERENCE Then
            the_decision_obj = hit_list(index).Tag
            enter_datetime_of_the_current_hit = CType(the_decision_obj, c05G_MovingAverageDifference).EnterTime
            minutes_passed_of_the_current_hit = CType(the_decision_obj, c05G_MovingAverageDifference).MinutesPassed
            'end_datetime_of_running_hit_no_overlap = CType(the_decision_obj, c05G_MovingAverageDifference).ExitTime
            'date_of_the_current_hit = hit_list(index).SubItems(0).Text
            'enter_time_of_the_current_hit = hit_list(index).SubItems(2).Text
            symbol_name_of_the_current_hit = hit_list(index).SubItems(4).Text.Substring(3)

            'Check duplicated
            If enter_datetime_of_the_current_hit = enter_datetime_of_the_previous_hit AndAlso minutes_passed_of_the_current_hit = minutes_passed_of_the_previous_hit AndAlso symbol_name_of_the_current_hit = symbol_name_of_the_previous_hit Then
                duplicated = True
            Else
                duplicated = False
            End If

            '평균 운용금액 구하기
            For running_index As Integer = running_hit_list_indexing.Count - 1 To 0 Step -1
                If CType(hit_list(running_hit_list_indexing(running_index)).Tag, c05G_MovingAverageDifference).ExitTime < enter_datetime_of_the_current_hit Then
                    running_hit_list_indexing.RemoveAt(running_index)
                End If
            Next
            If Not duplicated Then running_hit_list_indexing.Add(index)
            For running_index As Integer = 0 To running_hit_list_indexing.Count - 1
                If 0 AndAlso SecondStep Then
                    ave_invest += Math.Min(CType(hit_list(running_hit_list_indexing(running_index)).Tag, c05G_MovingAverageDifference).FallVolume * SILENT_INVOLVING_AMOUNT_RATE, INVEST_LIMIT)
                Else
                    ave_invest += CType(hit_list(running_hit_list_indexing(running_index)).Tag, c05G_MovingAverageDifference).FallVolume * SILENT_INVOLVING_AMOUNT_RATE
                End If
            Next

            'Update end time of current running hit
            If Not duplicated AndAlso (enter_datetime_of_the_current_hit > end_datetime_of_running_hit_no_overlap) Then
                end_datetime_of_running_hit_no_overlap = CType(the_decision_obj, c05G_MovingAverageDifference).ExitTime
            End If

            '일평균 최대 벌이
            If Not duplicated Then
                hit_count = hit_count + 1
                If 0 AndAlso SecondStep Then
                    max_earned += Math.Min(the_decision_obj.FallVolume * the_decision_obj.Profit * SILENT_INVOLVING_AMOUNT_RATE, INVEST_LIMIT)       'MovingAverageDifference용
                Else
                    max_earned += the_decision_obj.FallVolume * the_decision_obj.Profit * SILENT_INVOLVING_AMOUNT_RATE       'MovingAverageDifference용
                End If
            End If

            '겹침 제외 일평균 최대 벌이
            If end_datetime_of_running_hit_no_overlap <> end_datetime_of_running_hit_no_overlap_old Then
                no_overlap_hit_count += 1
                If 0 AndAlso SecondStep Then
                    no_overlap_max_earned += Math.Min(the_decision_obj.FallVolume * the_decision_obj.Profit * SILENT_INVOLVING_AMOUNT_RATE, INVEST_LIMIT)       'MovingAverageDifference용
                Else
                    no_overlap_max_earned += the_decision_obj.FallVolume * the_decision_obj.Profit * SILENT_INVOLVING_AMOUNT_RATE       'MovingAverageDifference용
                End If
                no_overlap_total_profit_plus1 *= 1 + the_decision_obj.Profit
            End If

            If Not duplicated Then
                profit_product *= 1 + CType(hit_list(index).Tag, c050_DecisionMaker).Profit
                min_profit = Math.Min(min_profit, CType(hit_list(index).Tag, c050_DecisionMaker).Profit)
                max_profit = Math.Max(max_profit, CType(hit_list(index).Tag, c050_DecisionMaker).Profit)
                total_volume += CType(hit_list(index).Tag, c050_DecisionMaker).FallVolume
            End If

            enter_datetime_of_the_previous_hit = enter_datetime_of_the_current_hit
            symbol_name_of_the_previous_hit = symbol_name_of_the_current_hit
            end_datetime_of_running_hit_no_overlap_old = end_datetime_of_running_hit_no_overlap
            minutes_passed_of_the_previous_hit = minutes_passed_of_the_current_hit
#Else
            date_of_the_current_hit = hit_list(index).SubItems(0).Text
            enter_time_of_the_current_hit = hit_list(index).SubItems(2).Text
            symbol_name_of_the_current_hit = hit_list(index).SubItems(4).Text.Substring(3)
            the_decision_obj = hit_list(index).Tag

            'Check duplicated
            If date_of_the_current_hit = date_of_the_previous_hit AndAlso enter_time_of_the_current_hit = enter_time_of_the_previous_hit AndAlso symbol_name_of_the_current_hit = symbol_name_of_the_previous_hit Then
                duplicated = True
            Else
                duplicated = False
            End If

            'Update end time of current running hit
            If Not duplicated AndAlso (date_of_the_current_hit <> date_of_the_previous_hit OrElse enter_time_of_the_current_hit > end_time_of_running_hit_no_overlap) Then
                end_time_of_running_hit_no_overlap = hit_list(index).SubItems(3).Text
            End If

            Dim invest_limit_multiplied As Double = INVEST_LIMIT
            If the_decision_obj.NumberOfEntering > 1 Then
                For entering_index As Integer = 0 To the_decision_obj.NumberOfEntering - 2
                    invest_limit_multiplied += INVEST_LIMIT * the_decision_obj.VOLUME_ATTENUATION
                Next
            End If

            '일평균 최대 벌이
            If Not duplicated Then
                hit_count = hit_count + 1

#If MOVING_AVERAGE_DIFFERENCE Then
                    max_earned += the_decision_obj.FallVolume * the_decision_obj.Profit * SILENT_INVOLVING_AMOUNT_RATE       'MovingAverageDifference용
#Else
                'max_earned += the_decision_obj.FallVolume * the_decision_obj.Profit / ((the_decision_obj.EnterTime - the_decision_obj.StartTime).TotalSeconds / 5) * SILENT_INVOLVING_AMOUNT_RATE
                'max_earned += the_decision_obj.FallVolume * the_decision_obj.Profit / CType(the_decision_obj, c05G_DeltaGangdo).DELTA_PERIOD * SILENT_INVOLVING_AMOUNT_RATE
                'max_earned += the_decision_obj.FallVolume * the_decision_obj.Profit / the_decision_obj.PatternLength * SILENT_INVOLVING_AMOUNT_RATE 'pattern
                max_earned += Math.Min(the_decision_obj.FallVolume / the_decision_obj.PatternLength * SILENT_INVOLVING_AMOUNT_RATE, invest_limit_multiplied) * the_decision_obj.Profit 'pattern
#End If
            End If

            '겹침 제외 일평균 최대 벌이
            If date_of_the_current_hit <> date_of_the_previous_hit OrElse end_time_of_running_hit_no_overlap <> end_time_of_running_hit_no_overlap_old Then
                no_overlap_hit_count += 1
#If MOVING_AVERAGE_DIFFERENCE Then
                   no_overlap_max_earned += the_decision_obj.FallVolume * the_decision_obj.Profit * SILENT_INVOLVING_AMOUNT_RATE       'MovingAverageDifference용
#Else
                no_overlap_max_earned += Math.Min(the_decision_obj.FallVolume / the_decision_obj.PatternLength * SILENT_INVOLVING_AMOUNT_RATE, invest_limit_multiplied) * the_decision_obj.Profit   'pattern
                'no_overlap_max_earned += the_decision_obj.FallVolume * the_decision_obj.Profit / the_decision_obj.PatternLength * SILENT_INVOLVING_AMOUNT_RATE  'pattern
                'no_overlap_max_earned += the_decision_obj.FallVolume * the_decision_obj.Profit / ((the_decision_obj.EnterTime - the_decision_obj.StartTime).TotalSeconds / 5) * SILENT_INVOLVING_AMOUNT_RATE
                'no_overlap_max_earned += the_decision_obj.FallVolume * the_decision_obj.Profit / CType(the_decision_obj, c05G_DeltaGangdo).DELTA_PERIOD * SILENT_INVOLVING_AMOUNT_RATE
#End If
                no_overlap_total_profit_plus1 *= 1 + the_decision_obj.Profit
            End If

            If Not duplicated Then
                profit_product *= 1 + CType(hit_list(index).Tag, c050_DecisionMaker).Profit
                min_profit = Math.Min(min_profit, CType(hit_list(index).Tag, c050_DecisionMaker).Profit)
                max_profit = Math.Max(max_profit, CType(hit_list(index).Tag, c050_DecisionMaker).Profit)
                total_volume += CType(hit_list(index).Tag, c050_DecisionMaker).FallVolume
            End If

            date_of_the_previous_hit = date_of_the_current_hit
            enter_time_of_the_previous_hit = enter_time_of_the_current_hit
            symbol_name_of_the_previous_hit = symbol_name_of_the_current_hit
            end_time_of_running_hit_no_overlap_old = end_time_of_running_hit_no_overlap
#End If
        Next
        lb_AveMaxEarned_NoOverlap.Text = lb_AveMaxEarned_NoOverlap.Tag.ToString & (no_overlap_max_earned / date_count).ToString("##,#")

        '검색된 건수
        lb_HitCount.Text = lb_HitCount.Tag.ToString & hit_count.ToString
        '일평균 검색건수
        lb_AveHitCount.Text = lb_AveHitCount.Tag.ToString & (hit_count / date_count).ToString

        lb_AveHitCountNoOverlap.Text = lb_AveHitCountNoOverlap.Tag.ToString & (no_overlap_hit_count.ToString / date_count).ToString
        '겹침 비율
        If hit_count > 0 Then
            lb_OverlapRate.Text = lb_OverlapRate.Tag.ToString & (1 - no_overlap_hit_count / hit_count).ToString("p")
        Else
            lb_OverlapRate.Text = "-"
        End If

        '평균 하강 볼륨
        If hit_count > 0 Then
            lb_AveFallVolume.Text = lb_AveFallVolume.Tag.ToString & (total_volume / hit_count).ToString("##,#")
        Else
            lb_AveFallVolume.Text = "-"
        End If
        '평균 실질 수익률
        'Dim profit_product As Double = 1
        'Dim min_profit As Double = [Double].MaxValue
        'Dim max_profit As Double = [Double].MinValue
        'For index As Integer = 0 To hit_list.Count - 1
        'profit_product *= 1 + CType(hit_list(index).Tag, c050_DecisionMaker).Profit
        'profit_product += CType(hit_list(index).Tag, c050_DecisionMaker).Profit
        'min_profit = Math.Min(min_profit, CType(hit_list(index).Tag, c050_DecisionMaker).Profit)
        'max_profit = Math.Max(max_profit, CType(hit_list(index).Tag, c050_DecisionMaker).Profit)
        'Next
        Dim ave_profit As Double
        If hit_count > 0 Then
            ave_profit = profit_product ^ (CType(1, Double) / hit_count) - 1
        Else
            ave_profit = 0
        End If
        'Dim ave_profit As Double = profit_product / hit_list.Count
        lb_AveProfit.Text = lb_AveProfit.Tag.ToString & (ave_profit).ToString("p")
        '최저 수익률
        lb_MinProfit.Text = lb_MinProfit.Tag.ToString & min_profit.ToString("p")
        '최고 수익률
        lb_MaxProfit.Text = lb_MaxProfit.Tag.ToString & max_profit.ToString("p")
        '겹침 제외 누적 수익률
        'lb_TotalProfitWithoutOverlap.Text = lb_TotalProfitWithoutOverlap.Tag.ToString & (((1 + ave_profit) ^ no_overlap_hit_count) - 1).ToString("p")
        lb_TotalProfitWithoutOverlap.Text = lb_TotalProfitWithoutOverlap.Tag.ToString & (no_overlap_total_profit_plus1 - 1).ToString("p")     '2021.03.14: 좀 더 현실적인 겹침 제외 누적수익률로 변경
        '겹침 제외 누적 수익률 (연환산)
        Dim day_ave_profit_no_overlap As Double = (no_overlap_total_profit_plus1) ^ (1 / date_count)        '일평균 겹침제외 수익률 + 1
        lb_AnualTotalprofitWithoutOverlap.Text = lb_AnualTotalprofitWithoutOverlap.Tag.ToString & (day_ave_profit_no_overlap ^ 240 - 1).ToString("p")       '겹침제외누적수익률(연환산) 240은 연평균 거래일수
        '평균 총 소요시간
        If hit_list.Count > 0 Then
            Dim total_time_sum As TimeSpan = TimeSpan.FromSeconds(0)
            Dim waiting_time_sum As TimeSpan = TimeSpan.FromSeconds(0)
            Dim having_time_sum As TimeSpan = TimeSpan.FromSeconds(0)
            For index As Integer = 0 To hit_list.Count - 1
                the_decision_obj = hit_list(index).Tag
                total_time_sum += the_decision_obj.TookTime
                waiting_time_sum += the_decision_obj.EnterTime - the_decision_obj.StartTime
#If MOVING_AVERAGE_DIFFERENCE Then
                having_time_sum += TimeSpan.FromMinutes(CType(the_decision_obj, c05G_MovingAverageDifference).MinutesPassed)
#Else
                'having_time_sum += the_decision_obj.ExitTime - the_decision_obj.EnterTime
#End If
            Next
            lb_AveTookTime.Text = lb_AveTookTime.Tag.ToString & TimeSpan.FromSeconds(total_time_sum.TotalSeconds / hit_list.Count).ToString("g")
            '평균 반등기다림 시간
            lb_AveWaitRisingTime.Text = lb_AveWaitRisingTime.Tag.ToString & TimeSpan.FromSeconds(waiting_time_sum.TotalSeconds / hit_list.Count).ToString("g")
            '평균 보유 시간
            lb_AveHavingTime.Text = lb_AveHavingTime.Tag.ToString & TimeSpan.FromSeconds(having_time_sum.TotalSeconds / hit_list.Count).ToString("g")
            '평균 보유시간/반등기다림시간 비율
            lb_AveHavingTimeRate.Text = lb_AveHavingTimeRate.Tag.ToString & (having_time_sum.TotalSeconds / waiting_time_sum.TotalSeconds).ToString("p")
        Else
            lb_AveTookTime.Text = "-"
            lb_AveWaitRisingTime.Text = "-"
            lb_AveHavingTime.Text = "-"
            lb_AveHavingTimeRate.Text = "-"
        End If
        '일평균 최대 벌이
        'Dim max_earned As Double = 0
        'For index As Integer = 0 To hit_list.Count - 1
        'the_decision_obj = hit_list(index).Tag
        'If DecisionByPattern Then
        'max_earned += the_decision_obj.FallVolume * the_decision_obj.Profit / the_decision_obj.PatternLength * SILENT_INVOLVING_AMOUNT_RATE
        'Else
        'max_earned += the_decision_obj.FallVolume * the_decision_obj.Profit / ((the_decision_obj.EnterTime - the_decision_obj.StartTime).TotalSeconds / 5) * SILENT_INVOLVING_AMOUNT_RATE
        'max_earned += the_decision_obj.FallVolume * the_decision_obj.Profit / CType(the_decision_obj, c05G_DeltaGangdo).DELTA_PERIOD * SILENT_INVOLVING_AMOUNT_RATE
        'End If
        'Next
        lb_AveMaxEarned.Text = lb_AveMaxEarned.Tag.ToString & (max_earned / date_count).ToString("##,#")
        '평균 운용금액
        lb_AveInvestMoney.Text = lb_AveInvestMoney.Tag.ToString & (ave_invest / hit_count).ToString("##,#")
        '기타 comment
        'SimulationResult 업데이트
        'SimulationResult = (ave_profit - 0.008) * no_overlap_hit_count / date_count ' no_overlap_max_earned / date_count * (ave_profit * 100 + 1) 'Math.Exp(ave_profit * 50)
        'SimulationResult = max_earned / date_count
        'SimulationResult = day_ave_profit_no_overlap ^ 240 - 1
        SimulationResult = max_earned / date_count - 1000 * (80 - hit_count / date_count) ^ 2

        InvokingDone = True
    End Sub

    '결과를 복사해 notepad 에 갖다붙인다
    Private Sub SaveAnalysis_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles bt_SaveAnalysis.Click
        Dim header As String = ""
        Dim content_line As String = ""

        '분석 날짜
        header += lb_AnalyzeDate.Text.Split(":")(0) & vbTab
        content_line += lb_AnalyzeDate.Text.Split(":")(1) & vbTab
        '시작 날짜
        header += lb_BeginDate.Text.Split(":")(0) & vbTab
        content_line += lb_BeginDate.Text.Split(":")(1) & vbTab
        '종료 날짜
        header += lb_EndDate.Text.Split(":")(0) & vbTab
        content_line += lb_EndDate.Text.Split(":")(1) & vbTab
        '유효 일수
        header += lb_DateCount.Text.Split(":")(0) & vbTab
        content_line += lb_DateCount.Text.Split(":")(1) & vbTab
        '적용 전략명
        header += lb_StrategyName.Text.Split(":")(0) & vbTab
        content_line += lb_StrategyName.Text.Split(":")(1) & vbTab
        '검색된 건수
        header += lb_HitCount.Text.Split(":")(0) & vbTab
        content_line += lb_HitCount.Text.Split(":")(1) & vbTab
        '일평균 검색건수
        header += lb_AveHitCount.Text.Split(":")(0) & vbTab
        content_line += lb_AveHitCount.Text.Split(":")(1) & vbTab
        '겹침제외 일평균 검색건수
        header += lb_AveHitCountNoOverlap.Text.Split(":")(0) & vbTab
        content_line += lb_AveHitCountNoOverlap.Text.Split(":")(1) & vbTab
        '겹침 비율
        header += lb_OverlapRate.Text.Split(":")(0) & vbTab
        content_line += lb_OverlapRate.Text.Split(":")(1) & vbTab
        '평균 하강 볼륨
        header += lb_AveFallVolume.Text.Split(":")(0) & vbTab
        content_line += lb_AveFallVolume.Text.Split(":")(1) & vbTab
        '평균 수익률
        header += lb_AveProfit.Text.Split(":")(0) & vbTab
        content_line += lb_AveProfit.Text.Split(":")(1) & vbTab
        '최저 수익률
        header += lb_MinProfit.Text.Split(":")(0) & vbTab
        content_line += lb_MinProfit.Text.Split(":")(1) & vbTab
        '최고 수익률
        header += lb_MaxProfit.Text.Split(":")(0) & vbTab
        content_line += lb_MaxProfit.Text.Split(":")(1) & vbTab
        '겹침 제외 누적 수익률
        header += lb_TotalProfitWithoutOverlap.Text.Split(":")(0) & vbTab
        content_line += lb_TotalProfitWithoutOverlap.Text.Split(":")(1) & vbTab
        '겹침 제외 누적 수익률 (연환산)
        header += lb_AnualTotalprofitWithoutOverlap.Text.Split(":")(0) & vbTab
        content_line += lb_AnualTotalprofitWithoutOverlap.Text.Split(":")(1) & vbTab
        '평균 총 소요시간
        header += lb_AveTookTime.Text.Split(":")(0) & vbTab
        content_line += lb_AveTookTime.Text.Substring(lb_AveTookTime.Text.IndexOf(":") + 1, lb_AveTookTime.Text.Length - lb_AveTookTime.Text.IndexOf(":") - 1) & vbTab
        '평균 반등기다림 시간
        header += lb_AveWaitRisingTime.Text.Split(":")(0) & vbTab
        content_line += lb_AveWaitRisingTime.Text.Substring(lb_AveWaitRisingTime.Text.IndexOf(":") + 1, lb_AveWaitRisingTime.Text.Length - lb_AveWaitRisingTime.Text.IndexOf(":") - 1) & vbTab
        '평균 보유 시간
        header += lb_AveHavingTime.Text.Split(":")(0) & vbTab
        content_line += lb_AveHavingTime.Text.Substring(lb_AveHavingTime.Text.IndexOf(":") + 1, lb_AveHavingTime.Text.Length - lb_AveHavingTime.Text.IndexOf(":") - 1) & vbTab
        '평균 보유시간/반등기다림시간 비율
        header += lb_AveHavingTimeRate.Text.Split(":")(0) & vbTab
        content_line += lb_AveHavingTimeRate.Text.Split(":")(1) & vbTab
        '기타 comment
        header += "기타 comment"
        content_line += " "

        '일평균 최대 벌이
        header += lb_AveMaxEarned.Text.Split(":")(0) & vbTab
        content_line += lb_AveMaxEarned.Text.Split(":")(1) & vbTab

        '겹침제외 일평균 최대 벌이
        header += lb_AveMaxEarned_NoOverlap.Text.Split(":")(0) & vbTab
        content_line += lb_AveMaxEarned_NoOverlap.Text.Split(":")(1) & vbTab

        '평균 운용금액
        header += lb_AveInvestMoney.Text.Split(":")(0) & vbTab
        content_line += lb_AveInvestMoney.Text.Split(":")(1) & vbTab

        'Coefficients
        If SmartLearning Then
            content_line += SimulationResult.ToString() & vbTab
            content_line += MADIFFSCA_FADE_FACTOR_MA0035.ToString() & vbTab
            content_line += MADIFFSCA_FADE_FACTOR_MA0070.ToString() & vbTab
            content_line += MADIFFSCA_FADE_FACTOR_MA0140.ToString() & vbTab
            content_line += MADIFFSCA_FADE_FACTOR_MA0280.ToString() & vbTab
            content_line += MADIFFSCA_FADE_FACTOR_MA0560.ToString() & vbTab
            content_line += MADIFFSCA_FADE_FACTOR_MA1200.ToString() & vbTab
            content_line += MADIFFSCA_FADE_FACTOR_MA2400.ToString() & vbTab
            content_line += MADIFFSCA_FADE_FACTOR_MA4800.ToString() & vbTab
            'content_line += MADIFFSCA_DETECT_SCALE_MA0035.ToString() & vbTab
            'content_line += REDUCE_ASSIGN_RATE.ToString() & vbTab
            'content_line += MADIFFSCA_A.ToString() & vbTab
            'content_line += MADIFFSCA_B.ToString() & vbTab
            'content_line += Form_TIME_DIFF_FOR_RISING_DETECTION.ToString() & vbTab
            'content_line += Form_RISING_SLOPE_THRESHOLD.ToString() & vbTab
            'content_line += Form_ENTERING_PROHIBIT_TIME.ToString() & vbTab
            'content_line += Form_TEMP_SLOPE1.ToString() & vbTab
            'content_line += Form_TEMP_SLOPE2.ToString() & vbTab
            content_line += TestIndex.ToString() & vbTab
            content_line += CoefficientsAlterListLenth.ToString() & vbTab
            content_line += NumberOfCoeffsInTrial.ToString() & vbTab
            'content_line += Form_DEFAULT_HAVING_TIME.ToString() & vbTab
            'content_line += Form_SCORE_THRESHOLD.ToString() & vbTab
            'content_line += Form_FALL_SCALE_LOWER_THRESHOLD.ToString() & vbTab
            'content_line += Form_MAX_HAVING_LENGTH.ToString() & vbTab
            'content_line += TestIndex.ToString() & vbTab
            'content_line += CoefficientsAlterListLenth.ToString() & vbTab
            'content_line += NumberOfCoeffsInTrial.ToString() & vbTab
        End If
#If CHECK_PRE_PATTERN_STRATEGY Then
        content_line += CountPostPatternFail.ToString() & vbTab
#End If
        'tb_Result.AppendText(header & vbCrLf)
        tb_Result.AppendText(content_line & vbCrLf)
        My.Computer.FileSystem.WriteAllText("smart_learning.txt", content_line & vbCrLf, True)
        Clipboard.SetText(header & vbCrLf & content_line)
    End Sub

    'save to clipboard
    Private Sub SaveToClipboardToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SaveToClipboardToolStripMenuItem.Click
        Dim line_str As String = ""
        'Dim number_of_columns As Integer = lv_DoneDecisions.Columns.Count
#If NO_SHOW_TO_THE_FORM Then
        For index As Integer = 0 To HitList.Count - 1
            For index_col As Integer = 0 To 9 '10 'lv_DoneDecisions.Items(index).SubItems.Count - 1
                line_str += HitList(index).SubItems(index_col).Text & vbTab
            Next
            line_str += vbCrLf
        Next
#Else
        For index As Integer = 0 To lv_DoneDecisions.Items.Count - 1
            For index_col As Integer = 0 To 10 'lv_DoneDecisions.Items(index).SubItems.Count - 1
                line_str += lv_DoneDecisions.Items(index).SubItems(index_col).Text & vbTab
            Next
            line_str += vbCrLf
        Next
#End If
        Clipboard.SetText(line_str)
    End Sub

    Private Sub trb_Accel_Scroll(sender As Object, e As EventArgs) Handles trb_Accel.Scroll
        DBSupporter.SetCpuLoadControl(trb_Accel.Value)

        AccelValueStored = trb_Accel.Value
    End Sub

#If ETRADE_CONNECTION Then
    Private Sub _T1305_ReceiveData(szTrCode As String) Handles _T1305.ReceiveData
        Dim symbol_code As String
        Dim count As Integer
        Dim close As Integer
        Dim change As Integer
        Dim sign As Integer
        Dim yester_price As Integer
        Dim this_date As String 
        Dim price_list As String = ""

        symbol_code = _T1305.GetFieldData("t1305OutBlock1", "shcode", 0)
        count = _T1305.GetFieldData("t1305OutBlock", "cnt", 0)
        For index As Integer = 0 To count - 1
            close = Convert.ToUInt32(_T1305.GetFieldData("t1305OutBlock1", "close", index))  '종가
            change = Convert.ToUInt32(_T1305.GetFieldData("t1305OutBlock1", "change", index))  '전일대비
            sign = Convert.ToUInt32(_T1305.GetFieldData("t1305OutBlock1", "sign", index))  '증감부호
            If sign = 2 Then
                yester_price = close - change
            Else 'if sign = 5 then
                yester_price = close + change
            End If
            this_date = _T1305.GetFieldData("t1305OutBlock1", "date", index)
            price_list = price_list & this_date & ", " & yester_price.ToString & vbCrLf
        Next

        My.Computer.FileSystem.WriteAllText("history1_" & symbol_code & ".txt", price_list, True)
        RxProcessCompleted = True
    End Sub


    Private Sub _ChartIndex_ReceiveData(szTrCode As String) Handles _ChartIndex.ReceiveData
        'Dim symbol_code As String
        Dim count As Integer
        'Dim close As Integer
        'Dim change As Integer
        'Dim sign As Integer
        'Dim yester_price As Integer
        'Dim this_date As String
        'Dim price_list As String = ""
        Dim date_str, time_str, open_str, high_str, low_str, close_str As String
        Dim line_text As String = ""

        'symbol_code = _ChartIndex.GetFieldData("ChartIndexOutBlock1", "shcode", 0)
        'count = _ChartIndex.GetFieldData("ChartIndexOutBlock", "cnt", 0)
        'g_indexId = XAQuery_ChartIndex.GetFieldData("ChartIndexOutBlock", "indexid", 0)

        ' 검색 종목수
        count = Convert.ToInt32(_ChartIndex.GetFieldData("ChartIndexOutBlock", "rec_cnt", 0))

        For index As Integer = 1 To count
            date_str = _ChartIndex.GetFieldData("ChartIndexOutBlock1", "date", index)     ' 일자
            time_str = _ChartIndex.GetFieldData("ChartIndexOutBlock1", "time", index)     ' 시간
            open_str = _ChartIndex.GetFieldData("ChartIndexOutBlock1", "open", index)     ' 시가
            high_str = _ChartIndex.GetFieldData("ChartIndexOutBlock1", "high", index)     ' 고가
            low_str = _ChartIndex.GetFieldData("ChartIndexOutBlock1", "low", index)      ' 저가
            close_str = _ChartIndex.GetFieldData("ChartIndexOutBlock1", "close", index)    ' 종가
            line_text = date_str & ", " & time_str & ", " & open_str & ", " & high_str & ", " & low_str & ", " & vbCrLf
            'Close = Convert.ToUInt32(_ChartIndex.GetFieldData("ChartIndexOutBlock1", "close", index))  '종가
            'change = Convert.ToUInt32(_ChartIndex.GetFieldData("ChartIndexOutBlock1", "change", index))  '전일대비
            'sign = Convert.ToUInt32(_ChartIndex.GetFieldData("ChartIndexOutBlock1", "sign", index))  '증감부호
            'If sign = 2 Then
            'yester_price = Close() - change
            'Else 'if sign = 5 then
            'yester_price = Close() + change
            'End If
            'this_date = _ChartIndex.GetFieldData("ChartIndexOutBlock1", "date", index)
            'price_list = price_list & this_date & ", " & yester_price.ToString & vbCrLf
        Next

        My.Computer.FileSystem.WriteAllText("ChartData\Minute\" & SymbolCodeOnRequest & ".txt", line_text, True)
        ResponseFlag = True
    End Sub
#End If

    Private Sub bt_Login_Click(sender As Object, e As EventArgs) Handles bt_Login.Click
#If ETRADE_CONNECTION Then
        LoginProcess()
#End If
    End Sub

    Private Sub bt_GlobalTrend_Click(sender As Object, e As EventArgs) Handles bt_GlobalTrend.Click
        '170821: DBSupport에 함수 하나 만들고(Simulate 참고해서) 그거 부르자
#If Not MOVING_AVERAGE_DIFFERENCE Then
        DBSupporter.GlobalTrending(dtp_StartDate.Value.Date, dtp_EndDate.Value.Date)
#End If
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        '검색된 종목을 날짜별로 sort
        MessageLogging("PartCount")
        For index As Integer = 0 To 9
            MessageLogging(PartCount(index))
        Next
        MessageLogging("PartProfit")
        For index As Integer = 0 To 9
            MessageLogging(PartMoney(index) / PartCount(index))
        Next
        SortDateTime()
    End Sub

    Private Sub SortDateTime()
#If NO_SHOW_TO_THE_FORM Then
        'TabControl1.SelectTab(3)
        '190917: no show로 했을 때 소트가 이상하니 한 번 봐라. 정 안 되면 별도 sort 펑션 만들어야 할 듯.
        'Dim i_comparer_time As New HitListComparer(2, SortOrder.Ascending, ListViewSortType.LV_SORT_STRING)
        'Dim i_comparer_date As New HitListComparer(0, SortOrder.Ascending, ListViewSortType.LV_SORT_STRING)

        HitList.Sort(AddressOf DateTimeComparison)
        InvokingDone = True
        'TabControl1.SelectTab(4)
#Else
        TabControl1.SelectTab(3)
        lv_DoneDecisions.ColumnSort(4)              '종목코드별 sorting, 소트가 어떤 때는 조금씩 다를 때도 있어서 이걸 추가함
        lv_DoneDecisions.ColumnSort(2)              '진입시간별 sorting
        lv_DoneDecisions.ColumnSort(0)              '날짜별 sorting
        InvokingDone = True
        TabControl1.SelectTab(4)
#End If
    End Sub

    Private Sub SortToMakeGlobalData()
        TabControl1.SelectTab(3)

        'EnterTime 에 맞추고 sort
        lv_DoneDecisions.ColumnSort(4)              '종목코드별 sorting, 소트가 어떤 때는 조금씩 다를 때도 있어서 이걸 추가함
        lv_DoneDecisions.ColumnSort(2)              '진입시간별 sorting
        lv_DoneDecisions.ColumnSort(0)              '날짜별 sorting

        'GlobalData 수집
        Dim the_decision_obj As c050_DecisionMaker
        For gullin_index As Integer = 0 To lv_DoneDecisions.Items.Count - 1
            the_decision_obj = lv_DoneDecisions.Items(gullin_index).Tag
            GlobalDataTime.Add(CType(the_decision_obj, c05G_MovingAverageDifference).EnterTime)
        Next

        '3번열을 having time 이 아니라 exit 시간으로 재설정하고 같은 방식으로 소트해보자.
        For gullin_index As Integer = 0 To lv_DoneDecisions.Items.Count - 1
            the_decision_obj = lv_DoneDecisions.Items(gullin_index).Tag
            lv_DoneDecisions.Items(gullin_index).Text = the_decision_obj.ExitTime.Date.ToString("d")
            lv_DoneDecisions.Items(gullin_index).SubItems(3).Text = the_decision_obj.ExitTime.TimeOfDay.ToString
        Next

        'ExitTime 에 맞추고 sort
        lv_DoneDecisions.ColumnSort(4)              '종목코드별 sorting, 소트가 어떤 때는 조금씩 다를 때도 있어서 이걸 추가함
        lv_DoneDecisions.ColumnSort(3)              '퇴장시간별 sorting
        lv_DoneDecisions.ColumnSort(0)              '날짜별 sorting

        Dim global_pointer As Integer = 0
        Dim current_gullin_count As Integer = 0
        For gullin_index As Integer = 0 To lv_DoneDecisions.Items.Count - 1
            the_decision_obj = lv_DoneDecisions.Items(gullin_index).Tag
            If global_pointer < GlobalDataTime.Count AndAlso GlobalDataTime(global_pointer) < the_decision_obj.ExitTime Then
                Do
                    current_gullin_count += 1
                    GlobalDataCount.Add(current_gullin_count)
                    global_pointer += 1
                Loop While global_pointer < GlobalDataTime.Count AndAlso GlobalDataTime(global_pointer) < the_decision_obj.ExitTime
            End If
            GlobalDataTime.Insert(global_pointer, the_decision_obj.ExitTime)
            global_pointer += 1
            current_gullin_count -= 1
            GlobalDataCount.Add(current_gullin_count)
        Next

        InvokingDone = True
        TabControl1.SelectTab(4)
    End Sub

    Private Function DateTimeComparison(ByVal x As ListViewItem, ByVal y As ListViewItem) As Integer
        Dim x_str As String = x.Text & x.SubItems(2).Text & x.SubItems(4).Text
        Dim y_str As String = y.Text & y.SubItems(2).Text & y.SubItems(4).Text

        Dim return_val = [String].Compare(x_str, y_str)
        Return return_val
    End Function
#If 0 Then
    Private Function TimeComparison(ByVal x As ListViewItem, ByVal y As ListViewItem) As Integer
        Dim return_val = [String].Compare(x.SubItems(2).Text, y.SubItems(2).Text)
        Return return_val
    End Function

    Private Function DateComparison(ByVal x As ListViewItem, ByVal y As ListViewItem) As Integer
        Dim return_val = [String].Compare(x.SubItems(0).Text, y.SubItems(0).Text)
        Return return_val
    End Function
#End If

#If ETRADE_CONNECTION Then
    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles bt_ChartDataUpdate.Click
        Dim chart_data_update_thread As Threading.Thread = New Threading.Thread(AddressOf ChartDataUpdateThread)
        chart_data_update_thread.IsBackground = True
        chart_data_update_thread.Start()     '시뮬레이션 스레드 돌리고  빠져나옴
        tm_FormUpdate.Start()       '관리 timer 시작
        'IsThreadExecuting = True
        bt_ChartDataUpdate.Enabled = False
    End Sub
#End If

    Private _db_connection As OleDb.OleDbConnection
    'Public TotalNumber, CurrentNumber As Integer
    Private Shared _CANDLE_CHART_FOLDER As String = "D:\Finance\Database\CandleChart\"
#If ETRADE_CONNECTION Then
    Public SymbolCodeOnRequest As String
    Public CtsDate As String = ""
    Public CtsTime As String = ""
    Private _TableNameToCheck As String
    Private _CandleChartInsertErrorCount As Integer

    Private Sub ChartDataUpdateThread()
        IsThreadExecuting = True
        Dim cmd As OleDb.OleDbCommand
        Dim command_text As String
        Dim read_result As OleDb.OleDbDataReader

        '최근 Price data DB로부터 종목정보를 모은다.
        Dim _DBList() As String = { _
         "PriceGangdoDB_201810", _
         "PriceGangdoDB_201811", _
         "PriceGangdoDB_201812", _
         "PriceGangdoDB_201901" _
        }
        Dim data_table As DataTable
        Dim table_name As String
        Dim table_name_list As New List(Of String)
        For db_index As Integer = 0 To _DBList.Count - 1
            _db_connection = New OleDb.OleDbConnection("Provider=SQLOLEDB;Data Source=" & PCName & "\SQLEXPRESS; Initial Catalog=" & _DBList(db_index) & "; Integrated Security=SSPI;")
            _db_connection.Open()
            data_table = _db_connection.GetSchema("tables")
            For table_index As Integer = 0 To data_table.Rows.Count - 1
                table_name = data_table.Rows(table_index).Item(2).ToString
                '테이블 이름이 종목코드와 같은 형식인지 검사(첫자가 A이고 길이가 7)
                If table_name(0) = "A" And table_name.Length = 7 Then
                    If Not table_name_list.Contains(table_name) Then
                        table_name_list.Add(table_name)
                    End If
                End If
            Next
            _db_connection.Close()
        Next

        'ChartData를 가져온다.
        '_db_connection = New OleDb.OleDbConnection("Provider=SQLOLEDB;Data Source=" & PCName & "\SQLEXPRESS; Initial Catalog=CandleChartDB; Integrated Security=SSPI;")
        '_db_connection.Open()

        'Candle Chart 테이블 이름 리스트를 만든다.
        'data_table = _db_connection.GetSchema("tables")
        'Dim candle_table_list As New List(Of String)
        'For table_index As Integer = 0 To data_table.Rows.Count - 1
        'candle_table_list.Add(data_table.Rows(table_index).Item(2).ToString)           '2번째 컬럼이 TABLE_NAME이다.
        'Next

        Dim db_exist As Boolean
        Dim db_name As String
        Dim candle_table_list As New List(Of String)
        TotalNumber = table_name_list.Count
        CurrentNumber = 0
        For table_index As Integer = 0 To table_name_list.Count - 1
            If table_name_list(table_index) <> "A000030" Then
                Continue For
            End If
            'If table_index > 2603 Then
            ' Continue For
            'End If
            '190201: 1분 chart만 할꺼니까 t8412로만 하자.
            If Now.Hour = 6 AndAlso Now.Minute > 30 Then
                '야간에만 한다
                While Not (Now.Hour = 15 AndAlso Now.Minute > 32)
                    Threading.Thread.Sleep(100)
                End While
                LoginProcess()
                Threading.Thread.Sleep(2000)
            End If

            '해당 종목 DB가 있는지 보고 없으면 만든다.
            db_name = "CandleChartDB_" & table_name_list(table_index)
            _db_connection = New OleDb.OleDbConnection("Provider=SQLOLEDB;Data Source=" & PCName & "\SQLEXPRESS;Integrated Security=SSPI;" & "Initial Catalog=" & db_name)
            Try
                _db_connection.Open()
                'DB 존재함
                db_exist = True
            Catch ex As Exception
                'DB 존재하지 않음
                db_exist = False
            End Try

            If Not db_exist Then
                'DB 생성
                _db_connection = New OleDb.OleDbConnection("Provider=SQLOLEDB;Data Source=" & PCName & "\SQLEXPRESS;Integrated Security=SSPI;")

                Try
                    'master DB 접속
                    _db_connection.Open()

                    command_text = "CREATE DATABASE " & db_name & " ON PRIMARY " & _
                          "(NAME = " & db_name & "_main, " & _
                          " FILENAME = '" & _CANDLE_CHART_FOLDER & db_name & "_main.mdf', " & _
                          " FILEGROWTH = 5MB) " & _
                          " LOG ON " & _
                          "(NAME = " & db_name & "_log, " & _
                          " FILENAME = '" & _CANDLE_CHART_FOLDER & db_name & "_log.ldf', " & _
                          " FILEGROWTH = 10%) "
                    cmd = New OleDb.OleDbCommand(command_text, _db_connection)
                    cmd.ExecuteNonQuery()
                    cmd.Dispose()
                    Threading.Thread.Sleep(10000) '좀 쉬었다가. 엄청 많이 쉬자. DB 파일 만든지 얼마 안 됐으니까
                Catch ex As Exception
                    'DB 생성에 실패했습니다.
                    MsgBox("DB 생성에 실패했습니다. 관리자에게 문의하세요.", MsgBoxStyle.Critical)
                    _db_connection.Close()              'DB connection 닫기
                    Exit Sub
                End Try
            End If

            _db_connection.Close()              'DB connection 닫기

            'DB 다시 열기 시도
            _db_connection = New OleDb.OleDbConnection("Provider=SQLOLEDB;Data Source=" & PCName & "\SQLEXPRESS;Integrated Security=SSPI;" & "Initial Catalog=" & db_name)

            Try
                _db_connection.Open()

                'Candle Chart 테이블 이름 리스트를 만든다.
                data_table = _db_connection.GetSchema("tables")
                candle_table_list.Clear()
                For candle_table_index As Integer = 0 To data_table.Rows.Count - 1
                    candle_table_list.Add(data_table.Rows(candle_table_index).Item(2).ToString)           '2번째 컬럼이 TABLE_NAME이다.
                Next

                _TableNameToCheck = table_name_list(table_index)
                If Not candle_table_list.Exists(AddressOf TableExistCheck) Then
                    '테이블 존재하지 않음 => 테이블 생성
                    command_text = "CREATE TABLE " & table_name_list(table_index) & "(CandleTime DATETIME PRIMARY KEY, OpenPrice INT, ClosePrice INT, HighPrice INT, LowPrice INT, Amount BIGINT);"
                    cmd = New OleDb.OleDbCommand(command_text, _db_connection)
                    cmd.ExecuteNonQuery()             '명령 실행
                    cmd.Dispose()
                Else
                    '테이블이 존재하면 => 이미 다입력되었다고 가정하고 다음 table로 가자 (임시로 하는 것임)
#If 0 Then
                    command_text = "SELECT * from " & table_name_list(table_index) & " WHERE CandleTime BETWEEN '2018-11-01 00:00:00' AND '2019-01-31 23:59:59' ORDER BY CandleTime ASC"
                    cmd = New OleDb.OleDbCommand(command_text, _db_connection)
                    read_result = cmd.ExecuteReader()
                    If read_result.Read Then
                        '데이타가 있다.=>이미 읽어서 저장되었다.=>건너 뛴다.
                        cmd.Dispose()
                        'Continue For
                    Else
                        '데이타가 없다.=>아래로 내려가 Chart data를 읽어 저장하는 작업을 한다.
                        cmd.Dispose()
                    End If
#End If
                End If
            Catch ex As Exception
                '생성에 성공했지만 여는데 실패.. why?
                MsgBox("DB 생성에 재~실패했습니다. 관리자에게 문의하세요.", MsgBoxStyle.Critical)
                _db_connection.Close()              'DB connection 닫기
                Exit Sub
            End Try

            'Candle Chart data 받기 위한 작업
            _T8412.ResFileName = "res\t8412.res"
            SymbolCodeOnRequest = table_name_list(table_index).Substring(1, table_name_list(table_index).Length - 1)

            _T8412.SetFieldData("t8412InBlock", "shcode", 0, SymbolCodeOnRequest)      '단축코드
            _T8412.SetFieldData("t8412InBlock", "ncnt", 0, "1L")        '단위(n틱/n분)
            _T8412.SetFieldData("t8412InBlock", "comp_yn", 0, "Y")      '압축여부(Y:압축,N:비압축)
            _T8412.SetFieldData("t8412InBlock", "sdate", 0, "20180701")       '시작일자(일/주/월 해당)
            _T8412.SetFieldData("t8412InBlock", "edate", 0, "20181031")       '종료일자(일/주/월 해당)

            Do
                ResponseReceived = False
                RxProcessCompleted = False
                If CtsDate = "" Then
                    RequestResult = _T8412.Request(False)
                Else
                    _T8412.SetFieldData("t8412InBlock", "cts_date", 0, CtsDate)       '다음 연속일자 입력
                    _T8412.SetFieldData("t8412InBlock", "cts_time", 0, CtsTime)       '다음 연속시간 입력
                    RequestResult = _T8412.Request(True)
                End If
                If RequestResult > 0 Then
                    Dim a = 0
                    Do
                        a = a + 1
                        Threading.Thread.Sleep(10)
                        If a = 3000 Then
                            My.Computer.FileSystem.WriteAllText("ChartData\" & SymbolCodeOnRequest & "_noresponse.txt", "", False)
                            NoResponseNumber = NoResponseNumber + 1
                            _T8412 = New XAQuery
                            LoginProcess()      '로긴을 다시 하고
                            CtsDate = ""        '후속 data 받는 거 없이 다음으로
                            CtsTime = ""        '넘어가기 위한 조치 취하고 가자
                            RxProcessCompleted = True
                            Exit Do
                        End If
                    Loop Until ResponseReceived
                    'Reponse 를 받았으면 이리 내려온다.
                    While Not RxProcessCompleted
                        Threading.Thread.Sleep(10)
                    End While
                    'Data 처리가 다 끝났으면 이리 내려온다.
                    Threading.Thread.Sleep(3000)
                Else
                    '에러나면 빠져나온다..
                    FailedSymbolNumber = FailedSymbolNumber + 1
                    My.Computer.FileSystem.WriteAllText("ChartData\" & SymbolCodeOnRequest & "_failed" & RequestResult.ToString & ".txt", "", False)
                    Exit Do
                End If
            Loop While CtsDate <> "" AndAlso CtsTime <> ""
            CurrentNumber = table_index
            _db_connection.Close()
        Next

        bt_ChartDataUpdate.Enabled = True
        CurrentNumber = TotalNumber
        IsThreadExecuting = False
    End Sub

    'table list에 있는지 체크
    Private Function TableExistCheck(ByVal a_string As String) As Boolean
        If a_string = _TableNameToCheck Then
            Return True
        Else
            Return False
        End If
    End Function

    Private Sub _T8412_ReceiveData(szTrCode As String) Handles _T8412.ReceiveData
        ResponseReceived = True

        Dim symbol_code As String
        Dim count As Integer
        Dim date_str, time_str, open_str, high_str, low_str, close_str, amount_str As String
        Dim year_str, month_str, day_str, hour_str, minute_str, second_str As String
        Dim line_text As String = ""
        Dim cmd As OleDb.OleDbCommand
        Dim insert_command As String

        symbol_code = _T8412.GetFieldData("t8412OutBlock", "shcode", 0)
        If _T8412.Decompress("t8412OutBlock1") > 0 Then
            count = _T8412.GetBlockCount("t8412OutBlock1")
        Else
            count = 0
        End If
        CtsDate = _T8412.GetFieldData("t8412OutBlock", "cts_date", 0)     ' 연속일자
        CtsTime = _T8412.GetFieldData("t8412OutBlock", "cts_time", 0)     ' 연속시간
        For index As Integer = count - 1 To 0 Step -1
            date_str = _T8412.GetFieldData("t8412OutBlock1", "date", index)     ' 날짜
            time_str = _T8412.GetFieldData("t8412OutBlock1", "time", index)     ' 시간
            year_str = date_str.Substring(0, 4)
            month_str = date_str.Substring(4, 2)
            day_str = date_str.Substring(6, 2)
            hour_str = time_str.Substring(0, 2)
            minute_str = time_str.Substring(2, 2)
            second_str = time_str.Substring(4, 2)

            open_str = _T8412.GetFieldData("t8412OutBlock1", "open", index)     ' 시가
            high_str = _T8412.GetFieldData("t8412OutBlock1", "high", index)     ' 고가
            low_str = _T8412.GetFieldData("t8412OutBlock1", "low", index)     ' 저가
            close_str = _T8412.GetFieldData("t8412OutBlock1", "close", index)     ' 종가
            amount_str = _T8412.GetFieldData("t8412OutBlock1", "jdiff_vol", index)     ' 거래량
            'line_text += date_str & ", " & time_str & ", " & open_str & ", " & high_str & ", " & low_str & ", " & last_str & ", " & amount_str & vbCrLf
            insert_command = "INSERT INTO A" & symbol_code & " (CandleTime, OpenPrice, ClosePrice, HighPrice, LowPrice, Amount) VALUES ('" & year_str & "-" & month_str & "-" & day_str & " " & hour_str & ":" & minute_str & ":" & second_str & "', " & open_str & ", " & close_str & ", " & high_str & ", " & low_str & ", " & amount_str & ");"
            cmd = New OleDb.OleDbCommand(insert_command, _db_connection)
            Try
                cmd.ExecuteNonQuery()              'insert 명령 실행
            Catch ex As Exception
                _CandleChartInsertErrorCount += 1
            End Try
            cmd.Dispose()
        Next

        RxProcessCompleted = True
    End Sub
#End If

    Private Sub Button3_Click_1(sender As Object, e As EventArgs) Handles bt_ChartDataValidate.Click
#If 0 Then
        '차트 데이타 밸리데이션
        Dim chart_data_validate_thread As Threading.Thread = New Threading.Thread(AddressOf ChartDataValidateThread)
        chart_data_validate_thread.IsBackground = True
        chart_data_validate_thread.Start()     '시뮬레이션 스레드 돌리고  빠져나옴
        tm_FormUpdate.Start()       '관리 timer 시작

        bt_ChartDataValidate.Enabled = False
#Else
        '차트 DB attach
        '차트 데이타 밸리데이션
        Dim chart_data_validate_thread As Threading.Thread = New Threading.Thread(AddressOf ChartDBAttachThread)
        chart_data_validate_thread.IsBackground = True
        chart_data_validate_thread.Start()     '시뮬레이션 스레드 돌리고  빠져나옴
        tm_FormUpdate.Start()       '관리 timer 시작

        bt_ChartDataValidate.Enabled = False
#End If
    End Sub

    Private Sub ChartDataValidateThread()
        IsThreadExecuting = True
        Dim cmd As OleDb.OleDbCommand
        Dim command_text As String
        Dim read_result As OleDb.OleDbDataReader

        Dim file_list = My.Computer.FileSystem.GetFiles(_CANDLE_CHART_FOLDER)
        Dim file_extension As String
        Dim db_name As String = ""
        Dim table_name As String
        Dim start_date, end_date As DateTime
        Dim start_date_string, end_date_string As String
        Dim this_date As DateTime
        Dim current_date As DateTime
        Dim data_count As Integer
        Dim count_count As Integer
        Dim datA_count_list(9) As Integer
        Dim datE_count_list(9) As Integer
        'TotalNumber = file_list.Count
        'CurrentNumber = 0
        'If cb_AutoUpdate.Checked Then
        start_date = Now.Date - TimeSpan.FromDays(Math.Ceiling(c03_Symbol.MAX_NUMBER_OF_CANDLE / 381)) 'dtp_LastCandleDate.Value
        start_date_string = start_date.ToString("yyyy-MM-dd")
        'Else
        'start_date = dtp_LastCandleDate.Value
        'start_date_string = start_date.ToString("yyyy-MM-dd")
        'End If
        end_date = Now.Date
        end_date_string = end_date.ToString("yyyy-MM-dd")

        For index As Integer = 0 To file_list.Count - 1
            file_extension = IO.Path.GetExtension(file_list(index))
            If file_extension = ".mdf" Then
                Try
                    db_name = IO.Path.GetFileName(file_list(index)).Substring(0, 21)
                    table_name = db_name.Substring(14, 7)
                    'DB open
                    _db_connection = New OleDb.OleDbConnection("Provider=SQLOLEDB;Data Source=" & PCName & "\SQLEXPRESS; Initial Catalog=" & db_name & "; Integrated Security=SSPI;")
                    _db_connection.Open()

                    command_text = "SELECT CandleTime from " & table_name & " WHERE CandleTime BETWEEN '" & start_date_string & " 00:00:00' AND '" & end_date_string & " 23:59:59' ORDER BY CandleTime ASC"
                    cmd = New OleDb.OleDbCommand(command_text, _db_connection)
                    read_result = cmd.ExecuteReader()

                    '루프 초기화
                    current_date = [DateTime].MinValue
                    data_count = 0
                    count_count = 0
                    For index_for_init As Integer = 0 To 9
                        datA_count_list(index_for_init) = 0
                        datE_count_list(index_for_init) = 0
                    Next
                    Dim count_count_index As Integer = 0
                    While 1
                        If read_result.Read Then
                            '데이타가 있다.
                            this_date = CType(read_result(0), DateTime).Date
                            If this_date <> current_date Then
                                '전까지 카운트했던 것을 기록한다.
                                If current_date = [DateTime].MinValue Then
                                    'initial 값이므로 패쓰
                                Else
                                    count_count_index = 0
                                    While count_count_index < count_count
                                        If datA_count_list(count_count_index) = data_count Then
                                            datE_count_list(count_count_index) += 1
                                            Exit While
                                        End If
                                        count_count_index += 1
                                    End While
                                    If count_count_index = count_count Then
                                        '해당 data_count인 날이 처음이니 새로 기록한다.
                                        datA_count_list(count_count) = data_count
                                        datE_count_list(count_count) = 1
                                        count_count += 1
                                    End If
                                    If data_count <> 381 Then
                                        datE_count_list(count_count - 1) = current_date.Year * 10000 + current_date.Month * 100 + current_date.Day
                                    End If
                                    If (this_date - current_date).Days > 10 Then
                                        '건너뛴 날짜가 너무 길어 뭔가 이상하니 기록한다.
                                        datA_count_list(count_count) = 30000 + (this_date - current_date).Days
                                        datE_count_list(count_count) = this_date.Year * 10000 + this_date.Month * 100 + this_date.Day
                                        count_count += 1
                                    End If
                                End If

                                '새 시작을 준비한다.
                                current_date = this_date
                                data_count = 1
                            Else
                                data_count += 1
                            End If
                        Else
                            '데이타가 없다.
                            cmd.Dispose()
                            Exit While
                        End If
                    End While
                    If current_date = [DateTime].MinValue Then
                        'initial 값이므로 패쓰
                    Else
                        '마지막 날짜 기록 (while 내 기록하는 부분 그대로 카피.. 별로 좋지 못한 디자인이지만 최적화하기 귀찮다)
                        count_count_index = 0
                        While count_count_index < count_count
                            If datA_count_list(count_count_index) = data_count Then
                                datE_count_list(count_count_index) += 1
                                Exit While
                            End If
                            count_count_index += 1
                        End While
                        If count_count_index = count_count Then
                            '해당 data_count인 날이 처음이니 새로 기록한다.
                            datA_count_list(count_count) = data_count
                            datE_count_list(count_count) = 1
                            count_count += 1
                        End If
                        If data_count <> 381 Then
                            datE_count_list(count_count - 1) = current_date.Year * 10000 + current_date.Month * 100 + current_date.Day
                        End If
                        If (this_date - current_date).Days > 10 Then
                            '건너뛴 날짜가 너무 길어 뭔가 이상하니 기록한다.
                            datA_count_list(count_count) = 30000 + (this_date - current_date).Days
                            datE_count_list(count_count) = this_date.Year * 10000 + this_date.Month * 100 + this_date.Day
                            count_count += 1
                        End If
                    End If
                Catch ex As Exception
                    Dim a = 1
                End Try

                '읽은 결과를 여기에서 쓴다.
                For result_index As Integer = 0 To count_count - 1
                    'My.Computer.FileSystem.WriteAllText("CharDataValidateResult.txt", db_name & ", " & result_index & " / " & count_count & ", " & datA_count_list(result_index) & ", " & datE_count_list(result_index) & vbCrLf, True)
                    MessageLogging("CharDataValidate : " & db_name & ", " & result_index & " / " & count_count & ", " & datA_count_list(result_index) & ", " & datE_count_list(result_index))
                Next

                ProgressText1 = index & "/" & file_list.Count
                _db_connection.Close()
            End If
            'CurrentNumber = index
        Next

        'CurrentNumber = TotalNumber
        IsThreadExecuting = False
    End Sub

    Private Sub ChartDBAttachThread()
        IsThreadExecuting = True
        Dim cmd As OleDb.OleDbCommand
        Dim command_text As String

        Dim file_list = My.Computer.FileSystem.GetFiles(_CANDLE_CHART_FOLDER)
        Dim file_extension As String
        Dim db_name As String
        'TotalNumber = file_list.Count
        'CurrentNumber = 0
        _db_connection = New OleDb.OleDbConnection("Provider=SQLOLEDB;Data Source=" & PCName & "\SQLEXPRESS;Integrated Security=SSPI;")
        'master DB 접속
        _db_connection.Open()

        For index As Integer = 0 To file_list.Count - 1
            file_extension = IO.Path.GetExtension(file_list(index))
            If file_extension = ".mdf" Then
                Try
                    db_name = IO.Path.GetFileName(file_list(index)).Substring(0, 21)

                    command_text = "CREATE DATABASE " & db_name & " ON (FILENAME = '" & _CANDLE_CHART_FOLDER & "\" & db_name & "_main.mdf')," _
                          & " (FILENAME = '" & _CANDLE_CHART_FOLDER & "\" & db_name & "_log.ldf') FOR ATTACH;"

                    cmd = New OleDb.OleDbCommand(command_text, _db_connection)
                    cmd.ExecuteNonQuery()
                    cmd.Dispose()
                    Threading.Thread.Sleep(100)
                Catch ex As Exception
                    'DB 생성에 실패했습니다.
                    MsgBox("DB 생성에 실패했습니다. 관리자에게 문의하세요.", MsgBoxStyle.Critical)
                    _db_connection.Close()              'DB connection 닫기
                    Exit Sub
                End Try

            End If

            'CurrentNumber = index
            ProgressText1 = index.ToString & " / " & file_list.ToString
        Next

        _db_connection.Close()              'DB connection 닫기

        'CurrentNumber = TotalNumber
        ProgressText1 = file_list.ToString & " / " & file_list.ToString
        IsThreadExecuting = False
    End Sub

    '모든 DB 제거 혹은 모든 DB 등록
    Private Sub RemoveAllChartDB()
        '리스트에서 읽어와서 drop 하자
        IsThreadExecuting = True
        Dim cmd As OleDb.OleDbCommand
        Dim command_text As String
        Dim db_name, table_name As String

        Dim table_name_list As New List(Of String)
#If 0 Then
        'Candle DB
        Dim file_list = My.Computer.FileSystem.GetFiles(_CANDLE_CHART_FOLDER)
        For index As Integer = 0 To file_list.Count - 1
            If IO.Path.GetExtension(file_list(index)) = ".mdf" Then
                db_name = IO.Path.GetFileName(file_list(index)).Substring(0, 21)
                table_name = db_name.Substring(14, 7)
                'If Not table_name_list.Contains(table_name) Then
                table_name_list.Add(table_name)
                'End If
            End If
        Next
#End If
        'Price DB
        Dim file_list = My.Computer.FileSystem.GetFiles("D:\Finance\Database")
        Dim extension, filename As String
        For index As Integer = 0 To file_list.Count - 1
            extension = IO.Path.GetExtension(file_list(index))
            filename = IO.Path.GetFileName(file_list(index))
            If extension = ".mdf" AndAlso filename.Substring(0, 13) = "PriceGangdoDB" Then
                'db_name = filename.Substring(0, 20)
                table_name = filename.Substring(0, 20)
                table_name_list.Add(table_name)
            End If
        Next

        _db_connection = New OleDb.OleDbConnection("Provider=SQLOLEDB;Data Source=" & PCName & "\SQLEXPRESS;Integrated Security=SSPI;")
        'master DB 접속
        _db_connection.Open()

        For index As Integer = 0 To table_name_list.Count - 1
            'If index >= 1842 Then
            'Continue For
            'End If
            'DB 삭제 혹은 붙이기
#If 0 Then
            'Chart DB
            db_name = "CandleChartDB_" & table_name_list(index)
#Else
            'Price DB
            db_name = table_name_list(index)
#End If
            Try
#If 0 Then
                command_text = "DROP DATABASE " & db_name
                cmd = New OleDb.OleDbCommand(command_text, _db_connection)
                cmd.ExecuteNonQuery()
                cmd.Dispose()
                MessageLogging("index " & index.ToString & ", " & db_name & " DB 삭제했습니다.")
                Threading.Thread.Sleep(100) '좀 쉬었다가. 엄청 많이 쉬자. DB 파일 삭제한지 얼마 안 됐으니까
#Else
#If 0 Then
                'Chart DB
                command_text = "CREATE DATABASE " & db_name & " ON PRIMARY " &
                      "(NAME = " & db_name & "_main, " &
                      " FILENAME = '" & _CANDLE_CHART_FOLDER & db_name & "_main.mdf', " &
                      " FILEGROWTH = 10%) " &
                      " LOG ON " &
                      "(NAME = " & db_name & "_log, " &
                      " FILENAME = '" & _CANDLE_CHART_FOLDER & db_name & "_log.ldf', " &
                      " FILEGROWTH = 10%) FOR ATTACH"
#Else
                'Price DB
                command_text = "CREATE DATABASE " & db_name & " ON PRIMARY " &
                      "(NAME = " & db_name & "_main, " &
                      " FILENAME = '" & "D:\Finance\Database\" & db_name & "_main.mdf', " &
                      " FILEGROWTH = 10%) " &
                      " LOG ON " &
                      "(NAME = " & db_name & "_log, " &
                      " FILENAME = '" & "D:\Finance\Database\" & db_name & "_log.ldf', " &
                      " FILEGROWTH = 10%) FOR ATTACH"
#End If
                cmd = New OleDb.OleDbCommand(command_text, _db_connection)
                cmd.ExecuteNonQuery()
                cmd.Dispose()
                MessageLogging("index " & index.ToString & ", " & db_name & " DB 붙였습니다.")
                Threading.Thread.Sleep(100) '좀 쉬었다가. 엄청 많이 쉬자. DB 파일 만든지 얼마 안 됐으니까
#End If
            Catch ex As Exception
                'DB 삭제에 실패했습니다.
                If LastExceptionErrorMesssage <> ex.Message Then
                    LastExceptionErrorMesssage = ex.Message
                    MessageLogging("Exception:" & "index " & index.ToString & ex.Message)
                End If
                'MsgBox("DB 삭제에 실패했습니다. 관리자에게 문의하세요.", MsgBoxStyle.Critical)
                _db_connection.Close()              'DB connection 닫기
                'Exit Sub
            End Try

            ProgressText1 = index & "/" & table_name_list.Count
        Next
        _db_connection.Close()

        IsThreadExecuting = False
    End Sub
End Class