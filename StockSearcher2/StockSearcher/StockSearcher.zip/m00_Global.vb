﻿'Compiler options
'180000, ETRADE_CONNECTION : Etrade Xing API ON
'181210, DEBUG_TOP_BOTTOM_PRICE_UPDATE : target pattern의 마지막 price를 Base Price라고 착각한 버그를 수정.
'181210, CHECK_PRE_PATTERN_STRATEGY : 매수성공률을 높이기 위한 방안으로 pre pattern 전략을 연구해보기로 함. =>버그로 인해 수익률 높게 나오는 걸 성공이라고 착각. 결론은 망했음.
'181210, MAKE_MEAN_SAME_BEFORE_GETTING_SCORE : Score 계산 전 pattern과 target의 mean을 같게 만듦
'190127, MOVING_AVERAGE_DIFFERENCE : moving average difference 전략 ON
'190128, MARKET_ENDTIME_DEBUG : 장종료시간 30분 연장된 거 뒤늦게 적용. (장종료시 열려있는 decision maker들 무시하지 않게 수정 하는 건 Moving Average Difference 전략에 default로 들어가있음. 그 이전 전략은 디폴트로 안 들어감. 그러므로 이 옵션과는 관계없음)
'190312, NO_SHOW_TO_THE_FORM : 걸린애들 폼에 표시하려니 메모리 부족하여 폼에 표시안하고 대신 리스트에 저장해두기
'190319, ALLOW_MULTIPLE_ENTERING : 진입한 후 가격이 더 떨어지면 추가 매수
'210427, DONT_FIX_THE_BUG_FOR_FLEXIBLE_FIX_20210427 : flexible pattern checker 전략 고정 전에 있던 버그 fix 할 건지 말 건지 여부
'210509, SIMULATION_PERIOD_IN_ARRAY : simulation 기간 선택을 form 에서 할 건지 test array 에서 할 건지 결정
'Imports DSCBO1Lib
'Imports CPUTILLib
Public Structure TracingKey
    Dim Var As Integer
    Dim Key As Integer
    Dim Time As TimeSpan
End Structure

Public Enum MARKET_KIND
    MK_NULL = 0
    MK_KOSPI = 1
    MK_KOSDAQ = 2
End Enum

Public Structure CandleStructure
    'Dim MinutesAfterStart As UInt32
    'Dim Variation5Minutes As Single
    Dim Average5Minutes As Single
    Dim Average30Minutes As Single
    Dim Average35Minutes As Single
    Dim Average70Minutes As Single
    Dim Average140Minutes As Single
    Dim Average280Minutes As Single
    Dim Average560Minutes As Single
    Dim Average1200Minutes As Single
    Dim Average2400Minutes As Single
    Dim Average4800Minutes As Single
    Dim VariationRatio As Single
    Dim CandleTime As DateTime
    Dim Open As UInt32
    Dim Close As UInt32
    Dim High As UInt32
    Dim Low As UInt32
    Dim Amount As UInt32
    Dim AccumAmount As UInt64
    Dim Test_MA_Var As Single
    'Dim Test_MA_Price As Single
End Structure

'161229: 빌드좀 어떻게 되게 해봐
Module m00_Global
    'Public SymTree As New c01_Symtree
    Public SymbolList As New List(Of c03_Symbol)
    Public MainForm As Form1
    Public MarketStartTime As Integer
#If MARKET_ENDTIME_DEBUG Then
    Public MarketEndHour As Integer
    Public MarketEndMinute As Integer
#Else
    Public MarketEndTime As Integer
#End If
    'Public MA_Base As Integer = 2
    Public PCName As String = "OCTAN"
    Public SimulationDateCollector As New List(Of Date)
    Public TraceVar As Integer
    'Public StoredMessagesForDisplay As New List(Of String)
    Public StoredMessagesKeyForDisplay As TracingKey 'Integer
    Public StoredMessagesForFileSave As New List(Of String)
#If Not MOVING_AVERAGE_DIFFERENCE Then
    Public DecisionByPattern As Boolean = True
#End If
    Public GangdoDB As Boolean = True
    Public SmartLearning As Boolean = False
    Public TwoStepSearching As Boolean = False
    Public SecondStep As Boolean = False
    Public MAX_HAVING_LENGTH As Integer = 140
    Public Const MULTIPLE_DECIDER As Boolean = True
    Public Const NUMBER_OF_DECIDERS As Integer = 1
    Public Const _MAX_NUMBER_OF_REQUEST As Integer = 110
    'Public Const LVSUB_YESTER_PRiCE As Integer = 2
    'Public Const LVSUB_YESTER_AMOUNT As Integer = 3
    'Public Const LVSUB_VOLUME As Integer = 4
    'Public Const LVSUB_INIT_PRICE As Integer = 5
    'Public Const LVSUB_NOW_PRICE As Integer = 6
    'Public Const LVSUB_AMOUNT As Integer = 7
    'Public Const LVSUB_GANGDO As Integer = 8
    'Public Const LVSUB_DATA_COUNT As Integer = 8
    'Public Const LVSUB_MOVING_AVERAGE_PRICE As Integer = 9
    'Public Const LVSUB_BUY_DELTA As Integer = 10
    'Public Const LVSUB_SEL_DELTA As Integer = 11
    Public Const TAX As Double = 0.003
    Public Const FEE As Double = 0.0002
#If MOVING_AVERAGE_DIFFERENCE Then
    Public Const SILENT_INVOLVING_AMOUNT_RATE As Double = 0.0333        'Moving Average Difference용
#Else
    Public Const SILENT_INVOLVING_AMOUNT_RATE As Double = 0.4
#End If
    Public Const INVEST_LIMIT As Double = Double.MaxValue ' 100000000
    Public Const NUMBER_OF_COEFFS As Integer = 8
    Public PartCount() As Integer = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}
    Public PartMoney() As Double = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}
    Public PartKey As TracingKey

    Public slope_stat(6) As Integer
    Public tt_1, tt_2 As Integer
#If 0 Then
    'MA 용
#If 0 Then
    Public TestArray() As String = {
      "2018-01-01"
    }
    Public TestArray2() As String = {
      "2018-09-30"
    }
#Else
    Public TestArray() As String = {
      "2018-01-01",
      "2019-01-01",
      "2019-10-01"
    }
    Public TestArray2() As String = {
      "2018-09-30",
      "2019-09-30",
      "2020-06-30"
    }
#End If
#Else
    '패턴용
    Public TestArray() As String = {
        "2018-01-01",
        "2018-04-01",
        "2018-07-01",
        "2018-10-01",
        "2019-01-01",
        "2019-04-01",
        "2019-07-01",
        "2019-10-01",
        "2020-03-01",
        "2020-04-01",
        "2020-07-01",
        "2020-10-01"
    }
    Public TestArray2() As String = {
        "2018-03-31",
        "2018-06-30",
        "2018-09-30",
        "2018-12-31",
        "2019-03-31",
        "2019-06-30",
        "2019-09-30",
        "2019-12-31",
        "2020-03-31",
        "2020-06-30",
        "2020-09-30",
        "2020-12-31"
    }
#End If
    'Public TestArray() As Double = {10, 13, 16, 19, 22, 25, 28, 31, 34}
    'Public TestArray() As Double = {0.7, 0.75, 0.8, 0.85, 0.9, 0.95, 1, 1.05, 1.1, 1.15, 1.2, 1.25, 1.3, 1.35, 1.4, 1.45, 1.5, 1.55, 1.6, 1.65, 1.7, 1.75, 1.8, 1.85, 1.9}

    Public TestIndex As Integer
    Public CoefficientsAlterListLenth As Integer
    Public NumberOfCoeffsInTrial As Integer
#If CHECK_PRE_PATTERN_STRATEGY Then
    Public CountPostPatternFail As Integer = 0
#End If
    Public GlobalDataTime As New List(Of DateTime)
    Public GlobalDataCount As New List(Of Integer)

    'Madiffsca
    Public MADIFFSCA_FADE_FACTOR_DEFAULT As Double = 0.44
    Public MADIFFSCA_FADE_FACTOR_MA0035 As Double = 0.44
    Public MADIFFSCA_FADE_FACTOR_MA0070 As Double = 0.44
    Public MADIFFSCA_FADE_FACTOR_MA0140 As Double = 0.44
    Public MADIFFSCA_FADE_FACTOR_MA0280 As Double = 0.44
    Public MADIFFSCA_FADE_FACTOR_MA0560 As Double = 0.44
    Public MADIFFSCA_FADE_FACTOR_MA1200 As Double = 0.44
    Public MADIFFSCA_FADE_FACTOR_MA2400 As Double = 0.44
    Public MADIFFSCA_FADE_FACTOR_MA4800 As Double = 0.44
    Public MADIFFSCA_DETECT_SCALE_MA0035 As Double = 1.2
    Public MADIFFSCA_DETECT_SCALE_MA0070 As Double = 1.2
    Public MADIFFSCA_DETECT_SCALE_MA0140 As Double = 1.2
    Public MADIFFSCA_DETECT_SCALE_MA0280 As Double = 1.2
    Public MADIFFSCA_DETECT_SCALE_MA0560 As Double = 1.2
    Public MADIFFSCA_DETECT_SCALE_MA1200 As Double = 1.2
    Public MADIFFSCA_DETECT_SCALE_MA2400 As Double = 1.2
    Public MADIFFSCA_DETECT_SCALE_MA4800 As Double = 1.2
    Public REDUCE_ASSIGN_RATE As Double = 0.0846
    Public MADIFFSCA_A As Double = 0.027
    Public MADIFFSCA_B As Double = 16.2


    Public Sub MessageLogging(ByVal message As String)
        SafeEnterTrace(StoredMessagesKeyForDisplay, 80)      'Enter critical zone, Thread간 공유문제 발생예방------------------------------------┐
        StoredMessagesForFileSave.Add("- " & Now.TimeOfDay.ToString & " : " & message & vbCrLf)
        SafeLeaveTrace(StoredMessagesKeyForDisplay, 81)      'Leave critical zone, Thread간 공유문제 발생예방------------------------------------┘

    End Sub
#If 0 Then
    Public Sub SafeEnter(ByRef using_flag As Integer)
        While System.Threading.Interlocked.CompareExchange(using_flag, 1, 0) = 1
            'Thread간 공유문제 발생예방
            System.Threading.Thread.Yield()
            '190806: account쪽에서 쓰는 곳 트레이스 가능하도록 바꾸고 이건 없애버리자
        End While
    End Sub

    Public Sub SafeLeave(ByRef using_flag As Integer)
        System.Threading.Interlocked.Exchange(using_flag, False) 'Thread간 공유문제 발생예방
    End Sub
#End If

    Public Sub SafeEnterTrace(ByRef tracing_key As TracingKey, ByVal user_index As Integer)
        While System.Threading.Interlocked.CompareExchange(tracing_key.Key, 1, 0) = 1
            'Thread간 공유문제 발생예방
            'System.Threading.Thread.Yield()
            System.Threading.Thread.Sleep(1)
        End While
        tracing_key.Var = user_index
        tracing_key.Time = Now.TimeOfDay
    End Sub

    Public Sub SafeLeaveTrace(ByRef tracing_key As TracingKey, ByVal user_index As Integer)
        tracing_key.Var = user_index
        System.Threading.Interlocked.Exchange(tracing_key.Key, False) 'Thread간 공유문제 발생예방
    End Sub

    Public Sub GlobalVarInit(ByVal main_form As Form1)
        MainForm = main_form

        'Dim cp_code_mgr As New CpCodeMgr()
        MarketStartTime = 9 'CType(cp_code_mgr.GetMarketStartTime(), Integer)
#If MARKET_ENDTIME_DEBUG Then
        MarketEndHour = 15
        MarketEndMinute = 30
#Else
        MarketEndTime = 15 ' CType(cp_code_mgr.GetMarketEndTime(), Integer)
#End If
    End Sub

    Public ReadOnly Property IsClearingTime(ByVal the_time As Date) As Boolean
        Get
            Dim current_time_of_day As TimeSpan = the_time.TimeOfDay
#If MARKET_ENDTIME_DEBUG Then
            Dim market_end_time As TimeSpan = TimeSpan.FromHours(MarketEndHour) + TimeSpan.FromMinutes(MarketEndMinute)
#Else
            Dim market_end_time As TimeSpan = TimeSpan.FromHours(MarketEndTime)
#End If

            If current_time_of_day >= market_end_time.Subtract(TimeSpan.FromMinutes(12)) AndAlso market_end_time > current_time_of_day Then
                Return True
            Else
                Return False
            End If
        End Get
    End Property

#if 0
    Public ReadOnly Property NoMoreEnteringTime(ByVal the_time As Date, ByVal having_time_in_seconds As Integer) As Boolean
        Get
            Dim current_time_of_day As TimeSpan = the_time.TimeOfDay
#If MARKET_ENDTIME_DEBUG Then
            Dim market_end_time As TimeSpan = TimeSpan.FromHours(MarketEndHour) + TimeSpan.FromMinutes(MarketEndMinute)
#Else
            Dim market_end_time As TimeSpan = TimeSpan.FromHours(MarketEndTime)
#End If

            If current_time_of_day >= market_end_time.Subtract(TimeSpan.FromSeconds(having_time_in_seconds + 12 * 60)) AndAlso market_end_time > current_time_of_day Then
                Return True
            Else
                Return False
            End If
        End Get
    End Property
#End If
    Public Function AddSymbolIfNew(ByVal symbol_code As String, ByVal symbol_name As String) As c03_Symbol
        Dim DoesSymbolExist As Boolean = False
        Dim symbol_obj As c03_Symbol = Nothing

        For index As Integer = 0 To SymbolList.Count - 1
            If SymbolList(index).Code = symbol_code Then
                DoesSymbolExist = True
                symbol_obj = SymbolList(index)
                Exit For
            End If
        Next

        If Not DoesSymbolExist Then
            'create a new symbol
            symbol_obj = New c03_Symbol(symbol_code, symbol_name)    '종목 개체 생성
            symbol_obj.DBTableExist = True
            Dim file_name As String = "history1_" & symbol_code.Substring(1, 6) & ".txt"
            If IO.File.Exists(file_name) Then
                Dim file_contents() As String = IO.File.ReadAllLines(file_name)
                'symbol_obj.MakeBasePriceHistory(file_contents)
            Else
                '파일이 없다는 것은 상장폐지
            End If
            SymbolList.Add(symbol_obj)                                     '종목리스트에 추가
            Return symbol_obj
        End If
        Return symbol_obj
    End Function

    Public Sub CollectSimulateDate(ByVal a_date As Date)
        Dim index As Integer = 0
        While index <= SimulationDateCollector.Count - 1
            If a_date < SimulationDateCollector(index) Then
                SimulationDateCollector.Insert(index, a_date)
                Exit While
            ElseIf a_date = SimulationDateCollector(index) Then
                Exit While
            End If
            index += 1
        End While
        If index = SimulationDateCollector.Count Then
            '가장 최근의 놈이다 => 마지막에 더한다
            SimulationDateCollector.Add(a_date)
        End If
    End Sub

#If 0 Then
    '시뮬레이션 속도를 높이기 위해 date collect하는 로직을 별도 thread로 돌리자
    Public Sub CollectSimulateDateByThreading(ByVal db_support_obj As c04_DBSupport)
        Dim a_date As Date
        Dim index As Integer = 0
        While db_support_obj.DateCollecting
            'SafeEnter(db_support_obj.DateListKey)      'Enter critical zone, Thread간 공유문제 발생예방------------------------------------┐
            'date list에서 date를 하나 추출한다
            If db_support_obj.DateListToCollect.Count > 0 Then
                a_date = db_support_obj.DateListToCollect(0)
                db_support_obj.DateListToCollect.RemoveAt(0)
            Else
                a_date = [Date].MinValue
            End If
            'SafeLeave(db_support_obj.DateListKey)      'Leave critical zone, Thread간 공유문제 발생예방------------------------------------┘

            If a_date <> [Date].MinValue Then
                While index <= SimulationDateCollector.Count - 1
                    If a_date < SimulationDateCollector(index) Then
                        SimulationDateCollector.Insert(index, a_date)
                        Exit While
                    ElseIf a_date = SimulationDateCollector(index) Then
                        Exit While
                    End If
                    index += 1
                End While
                If index = SimulationDateCollector.Count Then
                    '가장 최근의 놈이다 => 마지막에 더한다
                    SimulationDateCollector.Add(a_date)
                End If
            End If
        End While

    End Sub
#End If

    Public Function NumberOfGullin(the_time As DateTime) As Integer
        Dim the_pointer As Integer = 0

        If GlobalDataTime.Count = 0 Then
            Return -1
        End If

        If the_time < GlobalDataTime(the_pointer) Then
            Return 0
        Else
            Do
                the_pointer += 1
            Loop While the_pointer < GlobalDataTime.Count AndAlso the_time >= GlobalDataTime(the_pointer)

            Return GlobalDataCount(the_pointer - 1)
        End If
    End Function


End Module
